<?php

require_once '../bootstrap.php';

$security->auth();

$db = Database::getInstance();

$totalNews = $db->fetch(
    "SELECT COUNT(*) as total FROM news"
);

$totalEditions = $db->fetch(
    "SELECT COUNT(*) as total FROM editions"
);

$totalUsers = $db->fetch(
    "SELECT COUNT(*) as total FROM users"
);

$totalPublished = $db->fetch(
    "SELECT COUNT(*) as total
     FROM news
     WHERE status='published'"
);

?>

<link
rel="stylesheet"
href="<?= asset('css/epaper-ui.css') ?>"
>

<div class="admin-dashboard">

    <aside class="admin-sidebar">

        <div class="admin-logo">

            CMS

        </div>

        <nav>

            <a href="index.php">
                ড্যাশবোর্ড
            </a>

            <a href="news.php">
                সংবাদ
            </a>

            <a href="editions.php">
                সংস্করণ
            </a>

            <a href="media.php">
                মিডিয়া
            </a>

            <a href="settings.php">
                সেটিংস
            </a>

            <a href="logout.php">
                লগআউট
            </a>

        </nav>

    </aside>

    <main class="admin-main">

        <div class="stats-grid">

            <div class="stat-card">

                <h3>
                    মোট সংবাদ
                </h3>

                <strong>
                    <?= bn_number($totalNews['total']) ?>
                </strong>

            </div>

            <div class="stat-card">

                <h3>
                    প্রকাশিত সংবাদ
                </h3>

                <strong>
                    <?= bn_number($totalPublished['total']) ?>
                </strong>

            </div>

            <div class="stat-card">

                <h3>
                    সংস্করণ
                </h3>

                <strong>
                    <?= bn_number($totalEditions['total']) ?>
                </strong>

            </div>

            <div class="stat-card">

                <h3>
                    ব্যবহারকারী
                </h3>

                <strong>
                    <?= bn_number($totalUsers['total']) ?>
                </strong>

            </div>

        </div>

    </main>

</div>
<?php

require_once '../config.php';


$security->requireLogin();

?>


<h1>Dashboard</h1>


<ul>

<li><a href="news.php">Manage News</a></li>

<li><a href="editions.php">Manage Editions</a></li>

<li><a href="workflow.php">Workflow</a></li>

<li><a href="roles.php">Roles</a></li>

<li><a href="audit.php">Audit Logs</a></li>

</ul>

