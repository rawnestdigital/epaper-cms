public function delete($key)
{
    $file = CACHE_PATH . '/' . md5($key);

    if (file_exists($file)) {
        unlink($file);
    }
}
<?php


class Cache {


public function set($key, $data, $ttl = 3600) {


$payload = [

'expires' => time() + $ttl,

'data' => $data

];


file_put_contents(

CACHE_PATH . '/' . md5($key),

serialize($payload)

);

}


public function get($key) {


$file = CACHE_PATH . '/' . md5($key);


if (!file_exists($file)) {

return false;

}


$payload = unserialize(file_get_contents($file));


if ($payload['expires'] < time()) {

unlink($file);

return false;

}


return $payload['data'];

}

}

