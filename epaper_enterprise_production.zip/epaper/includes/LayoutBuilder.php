<?php

class LayoutBuilder
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getEditionLayout(int $editionId): array
    {
        return $this->db->fetchAll(
            "SELECT 
                id,
                edition_id,
                title,
                slug,
                image,
                status,
                sort_order,
                column_span,
                coordinate_x,
                coordinate_y,
                block_width,
                block_height
            FROM news
            WHERE edition_id = ?
            ORDER BY sort_order ASC, id ASC",
            [$editionId]
        );
    }

    public function saveLayout(int $editionId, array $blocks): bool
    {
        if (empty($blocks)) {
            throw new Exception('No layout blocks provided.');
        }

        try {

            $this->db->query('BEGIN');

            $sql = "
                UPDATE news SET
                    coordinate_x = :coordinate_x,
                    coordinate_y = :coordinate_y,
                    block_width = :block_width,
                    block_height = :block_height,
                    sort_order = :sort_order,
                    column_span = :column_span
                WHERE id = :id
                AND edition_id = :edition_id
            ";

            foreach ($blocks as $index => $block) {

                $params = [
                    ':coordinate_x' => (int) ($block['coordinate_x'] ?? 0),
                    ':coordinate_y' => (int) ($block['coordinate_y'] ?? 0),
                    ':block_width'  => (int) ($block['block_width'] ?? 1),
                    ':block_height' => (int) ($block['block_height'] ?? 1),
                    ':sort_order'   => (int) ($index + 1),
                    ':column_span'  => min(12, max(1, (int) ($block['column_span'] ?? 1))),
                    ':id'           => (int) $block['id'],
                    ':edition_id'   => $editionId
                ];

                $this->db->query($sql, $params);
            }

            $this->db->query('COMMIT');

            AuditLogger::log(
                'layout_saved',
                'Edition ID: ' . $editionId
            );

            $cache = new CacheAdvanced();
            $cache->delete('edition_layout_' . $editionId);

            return true;

        } catch (Throwable $e) {

            $this->db->query('ROLLBACK');

            AuditLogger::log(
                'layout_save_failed',
                $e->getMessage()
            );

            throw new Exception('Layout save failed.');
        }
    }
}