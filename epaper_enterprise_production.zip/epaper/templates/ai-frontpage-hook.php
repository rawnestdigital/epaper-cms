<?php
// templates/ai-frontpage-hook.php

require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/LayoutAIBridge.php';

$db = Database::getInstance()->pdo();
$ai = new LayoutAIBridge($db);

$page = 1;

$news = $ai->rankPage($page);
?>

<div class="epaper-container">

<?php foreach($news as $i=>$n): ?>

<div class="news-item col-<?= $n['column_span'] ?> <?= $i===0?'hero-news':'' ?>">

<h2><?= htmlspecialchars($n['title']) ?></h2>

<?php if($n['image']): ?>
<img src="/uploads/news/<?= $n['image'] ?>">
<?php endif; ?>

</div>

<?php endforeach; ?>

</div>