<?php

class RateLimiter {

    private Cache $cache;

    public function __construct() {

        try {

            $this->cache = new RedisCache();

        } catch(Exception $e) {

            $this->cache = new FileCache();
        }
    }

    public function attempt(string $key, int $max = 60, int $seconds = 60): bool {

        $count = $this->cache->get($key);

        if(!$count) {

            $this->cache->set($key, 1, $seconds);

            return true;
        }

        if($count >= $max) {

            return false;
        }

        $this->cache->set($key, $count + 1, $seconds);

        return true;
    }
}