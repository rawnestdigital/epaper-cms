<?php
// includes/Workflow.php

declare(strict_types=1);

final class Workflow
{
    public function __construct(private PDO $db) {}

    public function create(array $data): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO news (title, body, image, page_number, column_span, status)
            VALUES (?, ?, ?, ?, ?, 'Draft')
        ");

        return $stmt->execute([
            $data['title'],
            $data['body'],
            $data['image'],
            $data['page_number'],
            $data['column_span']
        ]);
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("
            UPDATE news
            SET title=?, body=?, image=?, page_number=?, column_span=?
            WHERE id=?
        ");

        return $stmt->execute([
            $data['title'],
            $data['body'],
            $data['image'],
            $data['page_number'],
            $data['column_span'],
            $id
        ]);
    }

    public function setStatus(int $id, string $status): bool
    {
        $stmt = $this->db->prepare("UPDATE news SET status=? WHERE id=?");
        return $stmt->execute([$status, $id]);
    }

    public function delete(int $id): bool
    {
        return $this->db->prepare("DELETE FROM news WHERE id=?")->execute([$id]);
    }

    public function all(): array
    {
        return $this->db->query("SELECT * FROM news ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    }
}
<?php
require_once __DIR__ . '/Database.php';

class Workflow {

    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->pdo();
    }

    /* Reporter submits news */
    public function submitToReview($newsId) {
        $stmt = $this->db->prepare("UPDATE news SET status = 'Pending' WHERE id = ?");
        return $stmt->execute([$newsId]);
    }

    /* Editor/Admin approves */
    public function publish($newsId) {
        $stmt = $this->db->prepare("UPDATE news SET status = 'Published' WHERE id = ?");
        return $stmt->execute([$newsId]);
    }

    public function reject($newsId) {
        $stmt = $this->db->prepare("UPDATE news SET status = 'Draft' WHERE id = ?");
        return $stmt->execute([$newsId]);
    }

    public function getByStatus($status) {
        $stmt = $this->db->prepare("SELECT * FROM news WHERE status = ?");
        $stmt->execute([$status]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllForPage($page) {
        $stmt = $this->db->prepare("
            SELECT * FROM news 
            WHERE page_number = ? AND status = 'Published'
            ORDER BY position_order ASC
        ");
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
<?php


class Workflow {


public function moveToReview($newsId) {


$db = Database::getInstance();


$db->query(

"UPDATE news SET status='review' WHERE id=?",

[$newsId]

);

}


public function approve($newsId) {


$db = Database::getInstance();


$db->query(

"UPDATE news SET status='published' WHERE id=?",

[$newsId]

);

}

}

