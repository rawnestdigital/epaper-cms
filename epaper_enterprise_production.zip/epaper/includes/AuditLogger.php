<?php
class AuditLogger{
 static function log($e,$d=''){
  Database::getInstance()->query('INSERT INTO audit_logs(event,details) VALUES(?,?)',[$e,$d]);
 }
}
<?php


class AuditLogger {


public static function log($action, $details = '') {


$line = sprintf(

"[%s] %s | %s | %s\n",

date('Y-m-d H:i:s'),

$_SESSION['user']['username'] ?? 'guest',

$action,

$details

);


file_put_contents(

LOG_PATH . '/audit.log',

$line,

FILE_APPEND

);

}

}

