<?php
// admin/news.php

require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Security.php';
require_once __DIR__ . '/../includes/Workflow.php';

Security::startSession();
Security::requireRole(['Admin','Editor','Reporter']);

$db = Database::getInstance()->pdo();
$wf = new Workflow($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!Security::verifyCsrf($_POST['csrf'] ?? null)) exit;

    $image = null;

    if (!empty($_FILES['image']['name'])) {
        $path = __DIR__ . '/../uploads/news/';
        if (!is_dir($path)) mkdir($path, 0777, true);

        $file = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $path . $file);
        $image = $file;
    }

    $wf->create([
        'title' => $_POST['title'],
        'body' => $_POST['body'],
        'image' => $image,
        'page_number' => (int)$_POST['page_number'],
        'column_span' => (int)$_POST['column_span']
    ]);
}

if (isset($_GET['publish'])) {
    $wf->setStatus((int)$_GET['publish'], 'Published');
}

if (isset($_GET['review'])) {
    $wf->setStatus((int)$_GET['review'], 'Pending');
}

if (isset($_GET['delete'])) {
    $wf->delete((int)$_GET['delete']);
}

$news = $wf->all();
$csrf = Security::csrfToken();
?>

<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= $csrf ?>">
<input name="title">
<textarea name="body"></textarea>
<input type="file" name="image">

<select name="page_number">
<?php for($i=1;$i<=6;$i++): ?>
<option value="<?= $i ?>"><?= $i ?></option>
<?php endfor; ?>
</select>

<select name="column_span">
<?php for($i=1;$i<=12;$i++): ?>
<option value="<?= $i ?>"><?= $i ?></option>
<?php endfor; ?>
</select>

<button>Create</button>
</form>

<?php foreach($news as $n): ?>
<div>
<?= $n['title'] ?>
<a href="?publish=<?= $n['id'] ?>">Publish</a>
<a href="?review=<?= $n['id'] ?>">Review</a>
<a href="?delete=<?= $n['id'] ?>">Delete</a>
</div>
<?php endforeach; ?>
<?php
require_once '../includes/Database.php';

$db = Database::getInstance()->pdo();

/* CREATE */
if (isset($_POST['create'])) {

    $imagePath = null;

    if (!empty($_FILES['image']['name'])) {
        $dir = "../uploads/news/";
        if (!is_dir($dir)) mkdir($dir, 0777, true);

        $file = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $dir . $file);

        $imagePath = $file;
    }

    $stmt = $db->prepare("
        INSERT INTO news (title, body, image, page_number, column_span)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $_POST['title'],
        $_POST['body'],
        $imagePath,
        $_POST['page_number'],
        $_POST['column_span']
    ]);
}

/* DELETE */
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM news WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
}

/* READ */
$news = $db->query("SELECT * FROM news ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>News Manager</h2>

<form method="POST" enctype="multipart/form-data">

    <input type="text" name="title" placeholder="News Title" required>

    <textarea name="body" placeholder="News Body" required></textarea>

    <input type="file" name="image">

    <select name="page_number">
        <?php for ($i=1; $i<=6; $i++): ?>
            <option value="<?= $i ?>">Page <?= $i ?></option>
        <?php endfor; ?>
    </select>

    <select name="column_span">
        <?php for ($i=1; $i<=12; $i++): ?>
            <option value="<?= $i ?>"><?= $i ?> Column</option>
        <?php endfor; ?>
    </select>

    <button name="create">Publish</button>
</form>

<hr>

<h3>All News</h3>

<?php foreach ($news as $n): ?>
    <div style="border:1px solid #ddd; padding:10px; margin:10px 0;">
        <h4><?= htmlspecialchars($n['title']) ?></h4>
        <p>Page: <?= $n['page_number'] ?> | Span: <?= $n['column_span'] ?></p>

        <?php if ($n['image']): ?>
            <img src="../uploads/news/<?= $n['image'] ?>" width="120">
        <?php endif; ?>

        <br>
        <a href="?delete=<?= $n['id'] ?>">Delete</a>
    </div>
<?php endforeach; ?>
<?php
require_once '../bootstrap.php';

$security->auth();

$news = new News();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = [

        'edition_id' => (int)$_POST['edition_id'],
        'category' => trim($_POST['category']),
        'title' => trim($_POST['title']),
        'slug' => trim($_POST['slug']),
        'summary' => trim($_POST['summary']),
        'content' => $_POST['content'],
        'image' => '',
        'page_number' => (int)$_POST['page_number'],
        'column_span' => (int)$_POST['column_span'],
        'sort_order' => (int)$_POST['sort_order'],
        'coordinate_x' => 0,
        'coordinate_y' => 0,
        'block_width' => 300,
        'block_height' => 200,
        'author_id' => $_SESSION['user']['id'],
        'status' => 'draft',
        'seo_title' => trim($_POST['seo_title']),
        'seo_description' => trim($_POST['seo_description'])
    ];

    if (!empty($_FILES['image']['name'])) {

        $upload = new ImagePipeline();

        $data['image'] = $upload->upload($_FILES['image']);
    }

    $news->create($data);

    header('Location: news.php');
    exit;
}
?>

<form method="POST" enctype="multipart/form-data">

    <div class="form-group">
        <label>সংবাদের শিরোনাম</label>
        <input type="text" name="title" required>
    </div>

    <div class="form-group">
        <label>স্লাগ</label>
        <input type="text" name="slug" required>
    </div>

    <div class="form-group">
        <label>পৃষ্ঠা নির্বাচন</label>

        <select name="page_number" required>

            <option value="1">১ম পৃষ্ঠা</option>
            <option value="2">২য় পৃষ্ঠা</option>
            <option value="3">৩য় পৃষ্ঠা</option>
            <option value="4">৪র্থ পৃষ্ঠা</option>
            <option value="5">৫ম পৃষ্ঠা</option>
            <option value="6">৬ষ্ঠ পৃষ্ঠা</option>

        </select>
    </div>

    <div class="form-group">
        <label>কত কলাম জায়গা নিবে</label>

        <select name="column_span">

            <option value="1">১ কলাম</option>
            <option value="2">২ কলাম</option>
            <option value="3">৩ কলাম</option>
            <option value="4">৪ কলাম</option>
            <option value="5">৫ কলাম</option>
            <option value="6">৬ কলাম</option>
            <option value="7">৭ কলাম</option>
            <option value="8">৮ কলাম</option>
            <option value="9">৯ কলাম</option>
            <option value="10">১০ কলাম</option>
            <option value="11">১১ কলাম</option>
            <option value="12" selected>১২ কলাম</option>

        </select>
    </div>

    <div class="form-group">

        <label>সংবাদের অবস্থান</label>

        <input
            type="number"
            name="sort_order"
            min="0"
            value="0"
        >

    </div>

    <div class="form-group">
        <label>ছবি</label>
        <input type="file" name="image">
    </div>

    <div class="form-group">
        <label>সংক্ষিপ্ত বিবরণ</label>
        <textarea name="summary"></textarea>
    </div>

    <div class="form-group">
        <label>পূর্ণ সংবাদ</label>
        <textarea name="content"></textarea>
    </div>

    <button type="submit">
        সংবাদ সংরক্ষণ করুন
    </button>

</form>