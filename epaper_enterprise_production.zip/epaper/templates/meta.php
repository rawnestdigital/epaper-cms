<?php

$seo = new Seo();

$meta = $seo->meta($metaData ?? []);

?>

<title><?= e($meta['title']) ?></title>

<meta
name="description"
content="<?= e($meta['description']) ?>"
>

<meta
property="og:title"
content="<?= e($meta['title']) ?>"
>

<meta
property="og:description"
content="<?= e($meta['description']) ?>"
>

<meta
property="og:image"
content="<?= e($meta['image']) ?>"
>

<meta
property="og:url"
content="<?= e($meta['url']) ?>"
>

<meta
name="twitter:card"
content="summary_large_image"
>

<meta
name="twitter:title"
content="<?= e($meta['title']) ?>"
>

<meta
name="twitter:description"
content="<?= e($meta['description']) ?>"
>

<meta
name="twitter:image"
content="<?= e($meta['image']) ?>"
>