<?php

class JWT
{
    private const ALGORITHM = 'sha256';

    public static function encode(
        array $payload,
        ?string $secret = null
    ): string {

        $secret ??= getenv('JWT_SECRET') ?: JWT_SECRET;

        $header = [
            'typ' => 'JWT',
            'alg' => 'HS256'
        ];

        $payload['iat'] = time();

        if (!isset($payload['exp'])) {
            $payload['exp'] = time() + 86400;
        }

        $headerEncoded = self::base64UrlEncode(
            json_encode($header, JSON_UNESCAPED_UNICODE)
        );

        $payloadEncoded = self::base64UrlEncode(
            json_encode($payload, JSON_UNESCAPED_UNICODE)
        );

        $signature = hash_hmac(
            self::ALGORITHM,
            $headerEncoded . '.' . $payloadEncoded,
            $secret,
            true
        );

        $signatureEncoded = self::base64UrlEncode($signature);

        return implode('.', [
            $headerEncoded,
            $payloadEncoded,
            $signatureEncoded
        ]);
    }

    public static function decode(
        string $token,
        ?string $secret = null
    ): array {

        $secret ??= getenv('JWT_SECRET') ?: JWT_SECRET;

        $parts = explode('.', $token);

        if (count($parts) !== 3) {
            throw new Exception('Invalid token structure.');
        }

        [
            $headerEncoded,
            $payloadEncoded,
            $signatureEncoded
        ] = $parts;

        $signature = self::base64UrlDecode($signatureEncoded);

        $expectedSignature = hash_hmac(
            self::ALGORITHM,
            $headerEncoded . '.' . $payloadEncoded,
            $secret,
            true
        );

        if (!hash_equals($expectedSignature, $signature)) {
            throw new Exception('Invalid token signature.');
        }

        $payload = json_decode(
            self::base64UrlDecode($payloadEncoded),
            true
        );

        if (!$payload) {
            throw new Exception('Invalid payload.');
        }

        if (
            isset($payload['exp']) &&
            time() > (int) $payload['exp']
        ) {
            throw new Exception('Token expired.');
        }

        return $payload;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(
            strtr(base64_encode($data), '+/', '-_'),
            '='
        );
    }

    private static function base64UrlDecode(string $data): string
    {
        return base64_decode(
            strtr($data, '-_', '+/')
        );
    }
}