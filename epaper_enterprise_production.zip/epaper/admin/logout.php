<?php
// admin/logout.php

require_once __DIR__ . '/../includes/Security.php';

Security::startSession();

session_unset();
session_destroy();

header('Location: /admin/login.php');
exit;