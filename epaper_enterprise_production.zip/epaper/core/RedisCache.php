<?php

class RedisCache implements Cache {

    private $redis;

    public function __construct() {

        if(!class_exists('Redis')) {

            throw new Exception('Redis not available');
        }

        $this->redis = new Redis();

        $this->redis->connect(
            getenv('REDIS_HOST') ?: '127.0.0.1',
            getenv('REDIS_PORT') ?: 6379
        );
    }

    public function get(string $key) {

        return unserialize($this->redis->get($key));
    }

    public function set(string $key, $value, int $ttl = 3600) {

        $this->redis->setex($key, $ttl, serialize($value));
    }

    public function delete(string $key) {

        $this->redis->del($key);
    }

    public function clear() {

        $this->redis->flushAll();
    }
}