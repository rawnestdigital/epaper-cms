<?php


class Template {


public function render(string $view, array $data = []): void {


extract($data);


require BASE_PATH . '/templates/header.php';


require BASE_PATH . '/templates/' . $view . '.php';


require BASE_PATH . '/templates/footer.php';

}


public function component(string $component, array $data = []): void {


extract($data);


require BASE_PATH . '/templates/components/' . $component . '.php';

}

}

