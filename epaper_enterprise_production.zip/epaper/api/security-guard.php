<?php
// api/security-guard.php

require_once __DIR__ . '/../includes/Security.php';

Security::startSession();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);

if (!Security::verifyCsrf($input['csrf'] ?? null)) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}

echo json_encode(['status' => 'ok']);