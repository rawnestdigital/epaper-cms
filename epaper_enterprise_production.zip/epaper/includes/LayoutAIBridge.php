<?php
// includes/LayoutAIBridge.php

require_once __DIR__ . '/Database.php';

final class LayoutAIBridge
{
    public function __construct(private PDO $db) {}

    public function rankPage(int $page): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM news
            WHERE page_number=? AND status='Published'
        ");

        $stmt->execute([$page]);
        $news = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($news as &$n) {
            $n['score'] = $this->score($n);
        }

        usort($news, fn($a,$b) => $b['score'] <=> $a['score']);

        return $news;
    }

    private function score(array $n): int
    {
        $score = 0;

        $score += max(0, 120 - strlen($n['title']));

        if (strpos($n['title'], 'Breaking') !== false) $score += 80;
        if (strpos($n['title'], 'Urgent') !== false) $score += 80;
        if (!empty($n['image'])) $score += 50;

        $score += ((int)$n['column_span'] * 3);

        return $score;
    }
}