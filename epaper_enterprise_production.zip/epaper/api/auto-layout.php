<?php
require_once '../includes/LayoutAI.php';

$ai = new LayoutAI();

$page = $_GET['page'] ?? 1;

$result = $ai->autoLayoutPage($page);

echo json_encode([
    "status" => "AI layout applied",
    "page" => $page,
    "items" => count($result)
]);