<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Premium Access Required</title>
<style>
body{
    margin:0;
    padding:30px;
    background:#f3f4f6;
    font-family:'Hind Siliguri','SolaimanLipi',sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
}
.card{
    background:#fff;
    padding:30px;
    border-radius:14px;
    max-width:480px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
}
h1{
    margin-top:0;
}
.btn{
    display:inline-block;
    margin-top:20px;
    background:#111827;
    color:#fff;
    text-decoration:none;
    padding:12px 20px;
    border-radius:8px;
}
<?php
// templates/paywall.php
?>
<div>
    Access Restricted. Subscribe to view full newspaper.
</div>
</style>
</head>
<body>
<div class="card">
<h1>প্রিমিয়াম কনটেন্ট</h1>
<p>
এই সংবাদটি পড়তে প্রিমিয়াম সাবস্ক্রিপশন প্রয়োজন।
</p>
<a href="/subscribe.php" class="btn">
সাবস্ক্রাইব করুন
</a>
</div>
</body>
</html>