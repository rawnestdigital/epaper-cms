<?php
function e($value) { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function asset($path) { return APP_URL . '/public/assets/' . ltrim($path, '/'); }
function redirect($url) { header('Location: ' . $url); exit; }
<?php

function asset($path){

    return APP_URL . '/public/assets/' . ltrim($path,'/');
}

function e($string){

    return htmlspecialchars(
        $string,
        ENT_QUOTES,
        'UTF-8'
    );
}

function bn_number($number){

    $en = ['0','1','2','3','4','5','6','7','8','9'];

    $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];

    return str_replace($en,$bn,$number);
}

function bn_date($date){

    $months = [

        'January'=>'জানুয়ারি',
        'February'=>'ফেব্রুয়ারি',
        'March'=>'মার্চ',
        'April'=>'এপ্রিল',
        'May'=>'মে',
        'June'=>'জুন',
        'July'=>'জুলাই',
        'August'=>'আগস্ট',
        'September'=>'সেপ্টেম্বর',
        'October'=>'অক্টোবর',
        'November'=>'নভেম্বর',
        'December'=>'ডিসেম্বর'
    ];

    $time = strtotime($date);

    $day = bn_number(date('d',$time));

    $month = $months[date('F',$time)];

    $year = bn_number(date('Y',$time));

    return "{$day} {$month} {$year}";
}