<?php

class ErrorHandler {

    private Logger $logger;

    public function __construct() {

        $this->logger = new Logger();

        set_error_handler([$this, 'handleError']);

        set_exception_handler([$this, 'handleException']);
    }

    public function handleError($level, $message, $file, $line) {

        $this->logger->error("$message in $file:$line");

        return true;
    }

    public function handleException($e) {

        $this->logger->error($e->getMessage());

        http_response_code(500);

        echo "Server Error";

        exit;
    }
}