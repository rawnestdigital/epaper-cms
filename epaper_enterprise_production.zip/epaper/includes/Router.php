<?php
class Router {
    public function dispatch() {
        $uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        if ($uri === '') { require BASE_PATH . '/templates/homepage.php'; return; }
        if (str_starts_with($uri, 'admin')) { require BASE_PATH . '/admin/index.php'; return; }
        $_GET['slug'] = basename($uri);
        require BASE_PATH . '/single.php';
    }
}
// includes/Router.php

final class Router
{
    public static function page(int $page): void
    {
        header("Location: /templates/epaper-view.php?page=" . $page);
        exit;
    }

    public static function admin(string $path): void
    {
        header("Location: /admin/" . $path);
        exit;
    }
}
<?php


class Router {


public function dispatch(): void {


$uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');


if ($uri === '') {

require BASE_PATH . '/templates/homepage.php';

return;

}


if (str_starts_with($uri, 'admin')) {

require BASE_PATH . '/admin/index.php';

return;

}


$_GET['slug'] = basename($uri);


require BASE_PATH . '/single.php';

}

}

