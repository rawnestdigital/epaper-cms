document.addEventListener('DOMContentLoaded', () => {

    const grid = document.getElementById('builderGrid');

    const saveButton = document.getElementById('saveLayoutBtn');

    const sortable = Sortable.create(grid, {
        animation: 180,
        ghostClass: 'sortable-ghost',
        dragClass: 'sortable-drag'
    });

    document.querySelectorAll('.column-span').forEach(select => {

        select.addEventListener('change', function () {

            const block = this.closest('.news-block');

            block.style.gridColumn = `span ${this.value}`;
        });
    });

    saveButton.addEventListener('click', async () => {

        try {

            const blocks = [];

            document.querySelectorAll('.news-block').forEach((block, index) => {

                const span = block.querySelector('.column-span').value;

                blocks.push({
                    id: parseInt(block.dataset.id),
                    sort_order: index + 1,
                    column_span: parseInt(span),
                    coordinate_x: 0,
                    coordinate_y: 0,
                    block_width: parseInt(span),
                    block_height: 1
                });
            });

            const response = await fetch(
                window.layoutBuilderConfig.saveUrl,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': window.layoutBuilderConfig.csrfToken
                    },
                    body: JSON.stringify({
                        edition_id: window.layoutBuilderConfig.editionId,
                        blocks: blocks
                    })
                }
            );

            const result = await response.json();

            if (result.status === 'success') {

                alert('Layout saved successfully.');

            } else {

                alert(result.message || 'Save failed.');
            }

        } catch (error) {

            console.error(error);

            alert('Unexpected error occurred.');
        }
    });
});
const grid = document.getElementById("builderGrid");

/* Drag reorder */
new Sortable(grid, {
    animation: 150,
    onEnd: function () {
        let items = [...document.querySelectorAll(".news-item")];

        let order = items.map((el, index) => ({
            id: el.dataset.id,
            position: index
        }));

        fetch("/api/update-layout.php", {
            method: "POST",
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ type: "order", data: order })
        });
    }
});

/* Update column span */
function updateSpan(id, span) {
    fetch("/api/update-layout.php", {
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            type: "span",
            id: id,
            span: span
        })
    }).then(() => location.reload());
}

/* PDF PRINT */
function generatePDF() {
    window.print();
}