<?php

class Environment {

    public static function load() {

        $file = BASE_PATH . '/.env';

        if(!file_exists($file)) return;

        $lines = file($file, FILE_IGNORE_NEW_LINES);

        foreach($lines as $line) {

            if(strpos($line,'=') === false) continue;

            [$key,$value] = explode('=', $line, 2);

            putenv(trim($key) . '=' . trim($value));
        }
    }

    public static function get(string $key, $default = null) {

        $value = getenv($key);

        return $value !== false ? $value : $default;
    }
}