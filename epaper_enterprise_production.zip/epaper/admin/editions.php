<?php

require_once '../bootstrap.php';

$security->auth();

$db = Database::getInstance();

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $title = trim($_POST['title']);

    $slug = trim($_POST['slug']);

    $publishDate = trim($_POST['publish_date']);

    $status = trim($_POST['status']);

    if(
        $title &&
        $slug &&
        $publishDate
    ){

        $db->query(
            "INSERT INTO editions
            (
                title,
                slug,
                publish_date,
                status,
                created_by
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?
            )",
            [
                $title,
                $slug,
                $publishDate,
                $status,
                $_SESSION['user']['id']
            ]
        );
    }

    header('Location: editions.php');

    exit;
}

$editions = $db->fetchAll(
    "SELECT *
     FROM editions
     ORDER BY publish_date DESC"
);

?>

<link
rel="stylesheet"
href="<?= asset('css/admin-dashboard.css') ?>"
>

<div class="admin-dashboard">

    <aside class="admin-sidebar">

        <div class="admin-logo">
            CMS
        </div>

        <nav>

            <a href="index.php">
                ড্যাশবোর্ড
            </a>

            <a href="news.php">
                সংবাদ
            </a>

            <a href="editions.php">
                সংস্করণ
            </a>

            <a href="media.php">
                মিডিয়া
            </a>

            <a href="settings.php">
                সেটিংস
            </a>

            <a href="logout.php">
                লগআউট
            </a>

        </nav>

    </aside>

    <main class="admin-main">

        <div class="page-header">

            <h1>
                সংস্করণ ব্যবস্থাপনা
            </h1>

        </div>

        <div class="admin-form-card">

            <form method="POST">

                <div class="form-grid">

                    <div class="form-group">

                        <label>
                            সংস্করণ শিরোনাম
                        </label>

                        <input
                            type="text"
                            name="title"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label>
                            স্লাগ
                        </label>

                        <input
                            type="text"
                            name="slug"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label>
                            প্রকাশের তারিখ
                        </label>

                        <input
                            type="date"
                            name="publish_date"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label>
                            স্ট্যাটাস
                        </label>

                        <select name="status">

                            <option value="draft">
                                Draft
                            </option>

                            <option value="published">
                                Published
                            </option>

                        </select>

                    </div>

                </div>

                <button class="save-btn">

                    সংস্করণ সংরক্ষণ

                </button>

            </form>

        </div>

        <div class="table-card">

            <table class="admin-table">

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>শিরোনাম</th>

                        <th>তারিখ</th>

                        <th>স্ট্যাটাস</th>

                    </tr>

                </thead>

                <tbody>

                    <?php foreach($editions as $edition): ?>

                        <tr>

                            <td>
                                <?= bn_number($edition['id']) ?>
                            </td>

                            <td>
                                <?= e($edition['title']) ?>
                            </td>

                            <td>
                                <?= bn_date($edition['publish_date']) ?>
                            </td>

                            <td>

                                <span class="
                                    status-badge
                                    <?= e($edition['status']) ?>
                                ">

                                    <?= e($edition['status']) ?>

                                </span>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </main>

</div>