<?php
// assets/js/viewer.js
?>

document.addEventListener("DOMContentLoaded", function () {

    const modal = document.createElement("div");
    modal.id = "newsModal";
    modal.innerHTML = `
        <div class="modal-inner">
            <span id="closeModal">×</span>
            <h2 id="mTitle"></h2>
            <div class="tabs">
                <button onclick="showTab('text')">Text</button>
                <button onclick="showTab('image')">Image</button>
            </div>
            <div id="mText"></div>
            <img id="mImage">
        </div>
    `;
    document.body.appendChild(modal);

    document.querySelectorAll(".news-item").forEach(el => {
        el.addEventListener("click", () => {
            document.getElementById("mTitle").innerText = el.querySelector("h2").innerText;
            document.getElementById("mText").innerText = el.dataset.body || el.innerText;
            document.getElementById("mImage").src = el.querySelector("img")?.src || "";
            modal.style.display = "block";
        });
    });

    document.getElementById("closeModal").onclick = () => {
        modal.style.display = "none";
    };
});

function showTab(type){
    document.getElementById("mText").style.display = type==='text'?'block':'none';
    document.getElementById("mImage").style.display = type==='image'?'block':'none';
}
function loadBreakingNews() {
    fetch('/api/breaking.php')
        .then(res => res.json())
        .then(data => {
            const bar = document.getElementById("breakingBar");

            if (data.length === 0) {
                bar.innerText = "কোনো ব্রেকিং নিউজ নেই";
                return;
            }

            bar.innerText = "🚨 " + data.join(" | ");
        });
}

setInterval(loadBreakingNews, 10000);
loadBreakingNews();
const modal = document.getElementById("newsModal");

document.querySelectorAll(".news-item").forEach(item => {
    item.addEventListener("click", () => {

        document.getElementById("modalTitle").innerText = item.dataset.title;
        document.getElementById("textView").innerText = item.dataset.body;

        const img = document.getElementById("imageView");
        img.src = item.dataset.image;

        modal.style.display = "block";
    });
});

/* CLOSE */
document.querySelector(".close").onclick = () => {
    modal.style.display = "none";
};

/* VIEW SWITCH */
function showView(type) {
    document.getElementById("textView").style.display = type === 'text' ? 'block' : 'none';
    document.getElementById("imageView").style.display = type === 'image' ? 'block' : 'none';
}

/* SHARE FUNCTIONS */
function shareWA() {
    window.open("https://wa.me/?text=" + window.location.href);
}

function shareFB() {
    window.open("https://www.facebook.com/sharer/sharer.php?u=" + window.location.href);
}

function copyLink() {
    navigator.clipboard.writeText(window.location.href);
    alert("Link copied!");
}