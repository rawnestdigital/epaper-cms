<?php


require_once '../bootstrap.php';


$security->requireLogin();


$db = Database::getInstance();


$subscriptions = $db->fetchAll(

"SELECT

s.*, u.username

FROM subscriptions s

LEFT JOIN users u

ON u.id = s.user_id

ORDER BY s.id DESC"

);


?>

<!DOCTYPE html>

<html lang="bn">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Subscribers</title>

<style>

body{

font-family:'Hind Siliguri','SolaimanLipi',sans-serif;

background:#f3f4f6;

margin:0;

padding:20px;

}

.table-wrap{

overflow:auto;

background:#fff;

border-radius:10px;

}

.table{

width:100%;

border-collapse:collapse;

}

.table th,

.table td{

padding:14px;

border-bottom:1px solid #e5e7eb;

text-align:left;

}

.table th{

background:#111827;

color:#fff;

}

@media(max-width:768px){

.table th,

.table td{

font-size:14px;

padding:10px;

}

}

</style>

</head>

<body>


<h2>Subscription Management</h2>


<div class="table-wrap">

<table class="table">

<thead>

<tr>

<th>User</th>

<th>Plan</th>

<th>Status</th>

<th>Expires</th>

<th>Created</th>

</tr>

</thead>

<tbody>

<?php foreach ($subscriptions as $subscription): ?>

<tr>

<td><?= e($subscription['username']) ?></td>

<td><?= e($subscription['plan']) ?></td>

<td><?= e($subscription['status']) ?></td>

<td><?= e($subscription['expires_at']) ?></td>

<td><?= e($subscription['created_at']) ?></td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


</body>

</html>

