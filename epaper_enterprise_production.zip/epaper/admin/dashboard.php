<?php
// admin/dashboard.php

require_once __DIR__ . '/../includes/Security.php';
require_once __DIR__ . '/../includes/Database.php';

Security::startSession();
Security::requireLogin();

$db = Database::getInstance()->pdo();

$user = $_SESSION['user'];

$stats = [
    'total_news' => $db->query("SELECT COUNT(*) FROM news")->fetchColumn(),
    'published'  => $db->query("SELECT COUNT(*) FROM news WHERE status='Published'")->fetchColumn(),
    'draft'      => $db->query("SELECT COUNT(*) FROM news WHERE status='Draft'")->fetchColumn(),
    'pending'    => $db->query("SELECT COUNT(*) FROM news WHERE status='Pending'")->fetchColumn()
];
?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<link rel="stylesheet" href="/assets/css/epaper.css">

<title>Admin Dashboard</title>
</head>

<body>

<div style="padding:20px">

<h2>Dashboard</h2>

<p>Welcome: <?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['role']) ?>)</p>

<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">

<div class="news-item">Total News: <?= $stats['total_news'] ?></div>
<div class="news-item">Published: <?= $stats['published'] ?></div>
<div class="news-item">Draft: <?= $stats['draft'] ?></div>
<div class="news-item">Pending: <?= $stats['pending'] ?></div>

</div>

</div>

</body>
</html>