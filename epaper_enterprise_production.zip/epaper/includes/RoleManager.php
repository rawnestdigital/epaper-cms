<?php
// includes/RoleManager.php

final class RoleManager
{
    public static function isSubscriber(): bool
    {
        return ($_SESSION['user']['role'] ?? '') === 'Subscriber';
    }

    public static function restrict(): void
    {
        if (!self::isSubscriber()) {
            header('Location: /templates/paywall.php');
            exit;
        }
    }
}
<?php


class RoleManager {


private $roles = [

'super_admin',

'editor',

'reporter',

'designer'

];


public function can($permission) {


$map = [

'publish' => ['super_admin', 'editor'],

'write' => ['reporter', 'editor'],

'design' => ['designer', 'editor'],

'manage_users' => ['super_admin']

];


$role = $_SESSION['user']['role'] ?? '';


return in_array($role, $map[$permission] ?? []);

}

}

