.page-header{
    margin-bottom:20px;
}

.page-header h1{
    margin:0;
    font-size:34px;
}

.admin-form-card{
    background:#fff;
    border-radius:12px;
    padding:24px;
    border:1px solid #ddd;
    margin-bottom:30px;
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
    gap:8px;
}

.form-group label{
    font-size:16px;
    font-weight:600;
}

.form-group input,
.form-group textarea,
.form-group select{
    border:1px solid #ddd;
    padding:14px;
    border-radius:8px;
    font-size:16px;
    background:#fff;
}

.save-btn{
    margin-top:20px;
    border:none;
    background:#c40000;
    color:#fff;
    padding:14px 24px;
    border-radius:8px;
    cursor:pointer;
    font-size:16px;
}

.table-card{
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    border:1px solid #ddd;
}

.admin-table{
    width:100%;
    border-collapse:collapse;
}

.admin-table thead{
    background:#111;
    color:#fff;
}

.admin-table th,
.admin-table td{
    padding:16px;
    border-bottom:1px solid #eee;
    text-align:left;
}

.status-badge{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:6px 12px;
    border-radius:40px;
    color:#fff;
    font-size:14px;
}

.status-badge.published{
    background:#00897b;
}

.status-badge.draft{
    background:#ff9800;
}

.media-grid{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
}

.media-card{
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    border:1px solid #ddd;
}

.media-card img{
    width:100%;
    height:220px;
    object-fit:cover;
}

.media-name{
    padding:14px;
    font-size:14px;
    word-break:break-word;
}

@media(max-width:992px){

    .media-grid{
        grid-template-columns:repeat(2,1fr);
    }

    .form-grid{
        grid-template-columns:1fr;
    }
}

@media(max-width:768px){

    .media-grid{
        grid-template-columns:1fr;
    }

    .admin-table{
        display:block;
        overflow:auto;
    }
}