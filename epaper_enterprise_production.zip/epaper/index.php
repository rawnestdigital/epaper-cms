
<?php
// FINAL index.php

require_once __DIR__ . '/includes/Database.php';

$db = Database::getInstance()->pdo();

$news = $db->query("
    SELECT * FROM news 
    WHERE status='Published'
    ORDER BY position_order ASC
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="/assets/css/epaper.css">
<link rel="stylesheet" href="/assets/css/print.css">
<script defer src="/assets/js/viewer.js"></script>
</head>

<body>

<div class="epaper-container">

<?php foreach($news as $i=>$n): ?>

<div class="news-item col-<?= $n['column_span'] ?> <?= $i==0?'hero-news':'' ?>"
     data-body="<?= htmlspecialchars($n['body']) ?>">

<h2><?= htmlspecialchars($n['title']) ?></h2>

<?php if($n['image']): ?>
<img src="/uploads/news/<?= $n['image'] ?>">
<?php endif; ?>

</div>

<?php endforeach; ?>

</div>

</body>
</html>
<?php
// index.php (FINAL SAFE ENTRY WRAPPER)

require_once __DIR__ . '/includes/BootstrapCheck.php';
require_once __DIR__ . '/includes/Database.php';

BootstrapCheck::run();

$db = Database::getInstance()->pdo();

$news = $db->query("
    SELECT * FROM news
    WHERE status='Published'
    ORDER BY position_order ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="bn">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<link rel="stylesheet" href="/assets/css/epaper.css">
<link rel="stylesheet" href="/assets/css/print.css">

<script defer src="/assets/js/viewer.js"></script>
<title>ePaper</title>
</head>

<body>

<div class="epaper-container">

<?php foreach($news as $i => $n): ?>

<div class="news-item col-<?= $n['column_span'] ?> <?= $i===0?'hero-news':'' ?>"
     data-body="<?= htmlspecialchars($n['body']) ?>">

<h2><?= htmlspecialchars($n['title']) ?></h2>

<?php if(!empty($n['image'])): ?>
<img src="/uploads/news/<?= $n['image'] ?>">
<?php endif; ?>

</div>

<?php endforeach; ?>

</div>

</body>
</html>

Options -Indexes

RewriteEngine On

RewriteRule ^page/([0-9]+)/?$ templates/epaper-view.php?page=$1 [L,QSA]
RewriteRule ^admin$ admin/login.php [L]
RewriteRule ^api/(.*)$ api/$1.php [L]

RedirectMatch 403 ^/database/
RedirectMatch 403 ^/includes/
RedirectMatch 403 ^/uploads/private/

<FilesMatch "\.db$">
Deny from all
</FilesMatch>

<IfModule mod_headers.c>
Header set X-Frame-Options "DENY"
Header set X-Content-Type-Options "nosniff"
Header set X-XSS-Protection "1; mode=block"
</IfModule>
<?php
// index.php

require_once __DIR__ . '/includes/Database.php';

$db = Database::getInstance()->pdo();

$news = $db->query("SELECT * FROM news WHERE status='Published' ORDER BY position_order ASC")->fetchAll();
?>

<div class="epaper-container">

<?php foreach($news as $i=>$n): ?>

<div class="news-item col-<?= $n['column_span'] ?> <?= $i==0?'hero-news':'' ?>">

<h2><?= $n['title'] ?></h2>

<?php if($n['image']): ?>
<img src="/uploads/news/<?= $n['image'] ?>">
<?php endif; ?>

</div>

<?php endforeach; ?>

</div>
<?php

require_once 'config.php';


$news = new News();

$latest = $news->latest();

?>


<!DOCTYPE html>

<html>

<head>

<title><?= APP_NAME ?></title>

</head>

<body>


<h1><?= APP_NAME ?></h1>


<?php foreach ($latest as $item): ?>


<article>

<h2>

<a href="<?= $item['slug'] ?>">

<?= htmlspecialchars($item['title']) ?>

</a>

</h2>

</article>


<?php endforeach; ?>


</body>

</html>

