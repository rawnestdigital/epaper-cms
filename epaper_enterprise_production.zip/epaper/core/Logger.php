<?php

class Logger {

    private string $file;

    public function __construct() {

        $this->file = BASE_PATH . '/storage/logs/app.log';
    }

    public function info(string $msg) {

        $this->write('INFO', $msg);
    }

    public function error(string $msg) {

        $this->write('ERROR', $msg);
    }

    public function warning(string $msg) {

        $this->write('WARNING', $msg);
    }

    private function write(string $level, string $msg) {

        file_put_contents(
            $this->file,
            "[" . date('Y-m-d H:i:s') . "] [$level] $msg\n",
            FILE_APPEND
        );
    }
}