<?php

session_start();


define('BASE_PATH', __DIR__);

define('STORAGE_PATH', BASE_PATH . '/storage');

define('CACHE_PATH', STORAGE_PATH . '/cache');

define('UPLOAD_PATH', STORAGE_PATH . '/uploads');

define('LOG_PATH', STORAGE_PATH . '/logs');

define('DB_PATH', BASE_PATH . '/database/epaper.sqlite');


define('APP_NAME', 'Enterprise ePaper CMS');

define('APP_URL', 'https://yourdomain.com');

define('APP_ENV', 'production');


date_default_timezone_set('Asia/Dhaka');


spl_autoload_register(function ($class) {

$file = BASE_PATH . '/includes/' . $class . '.php';

if (file_exists($file)) {

require_once $file;

}

});


$db = Database::getInstance();

$security = new Security();

<?php
define('BASE_PATH', __DIR__);
define('STORAGE_PATH', BASE_PATH . '/storage');
define('UPLOAD_PATH', STORAGE_PATH . '/uploads');
define('CACHE_PATH', STORAGE_PATH . '/cache');
define('LOG_PATH', STORAGE_PATH . '/logs');
define('DB_PATH', BASE_PATH . '/database/epaper.sqlite');
define('APP_URL', 'http://localhost:8080');
define('JWT_SECRET', 'change_me');
define('APP_ENV', 'production');

// config/env.php (FINAL PRODUCTION CONFIG)

define('APP_NAME', 'Enterprise ePaper CMS');
define('APP_VERSION', '5.0.0');
define('ASSET_VERSION', '5.0.0');

define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('DB_PATH', __DIR__ . '/../database/app.db');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);
<?php


define('BASE_PATH', __DIR__);

define('APP_NAME', 'Enterprise ePaper CMS');

define('APP_ENV', 'production');

define('APP_DEBUG', false);

define('APP_URL', 'https://yourdomain.com');

define('TIMEZONE', 'Asia/Dhaka');


define('DATABASE_PATH', BASE_PATH . '/database/epaper.sqlite');

define('STORAGE_PATH', BASE_PATH . '/storage');

define('UPLOAD_PATH', STORAGE_PATH . '/uploads');

define('CACHE_PATH', STORAGE_PATH . '/cache');

define('LOG_PATH', STORAGE_PATH . '/logs');

define('SESSION_PATH', STORAGE_PATH . '/sessions');


date_default_timezone_set(TIMEZONE);


mb_internal_encoding('UTF-8');


ini_set('session.save_path', SESSION_PATH);

ini_set('session.use_strict_mode', 1);

ini_set('session.cookie_httponly', 1);

ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));

ini_set('session.cookie_samesite', 'Lax');


error_reporting(E_ALL);


if (!APP_DEBUG) {

ini_set('display_errors', 0);

ini_set('log_errors', 1);

ini_set('error_log', LOG_PATH . '/php-error.log');

}


set_exception_handler(function ($e) {


file_put_contents(

LOG_PATH . '/exception.log',

'[' . date('Y-m-d H:i:s') . '] ' . $e->getMessage() . PHP_EOL,

FILE_APPEND

);


http_response_code(500);


echo 'Application Error';

});

