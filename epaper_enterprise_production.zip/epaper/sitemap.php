<?php
// sitemap.php

require_once __DIR__ . '/includes/Database.php';

$db = Database::getInstance()->pdo();

header("Content-Type: application/xml; charset=utf-8");

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$news = $db->query("SELECT id FROM news WHERE status='Published'");

foreach ($news as $n) {
    echo "<url><loc>/news/{$n['id']}</loc></url>";
}

echo '</urlset>';