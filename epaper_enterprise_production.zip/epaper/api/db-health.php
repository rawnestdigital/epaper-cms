<?php
// api/db-health.php

require_once __DIR__ . '/../includes/Database.php';

header('Content-Type: application/json');

try {
    $db = Database::getInstance()->pdo();
    $db->query("SELECT 1");

    echo json_encode([
        'status' => 'healthy',
        'database' => 'connected'
    ]);

} catch (Throwable $e) {
    http_response_code(500);

    echo json_encode([
        'status' => 'error',
        'database' => 'failed'
    ]);
}