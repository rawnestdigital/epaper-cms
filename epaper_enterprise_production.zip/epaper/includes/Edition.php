<?php


class Edition {


public function all() {


$db = Database::getInstance();


return $db->fetchAll(

"SELECT * FROM editions ORDER BY publish_date DESC"

);

}

}

<?php


class Edition {


private Database $db;


public function __construct() {

$this->db = Database::getInstance();

}


public function all(): array {


return $this->db->fetchAll(

'SELECT * FROM editions ORDER BY publish_date DESC'

);

}


public function publish(int $id): bool {


$this->db->query(

'UPDATE editions SET status = ? WHERE id = ?',

['published', $id]

);


return true;

}


public function draft(int $id): bool {


$this->db->query(

'UPDATE editions SET status = ? WHERE id = ?',

['draft', $id]

);


return true;

}

}

