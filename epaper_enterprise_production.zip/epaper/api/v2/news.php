<?php

$db = Database::getInstance();

$action = $segments[1] ?? 'latest';

try {

    if ($method !== 'GET') {
        throw new Exception('Invalid request method.');
    }

    if ($action === 'latest') {

        $limit = (int) ($_GET['limit'] ?? 20);

        if ($limit <= 0 || $limit > 100) {
            $limit = 20;
        }

        $news = $db->fetchAll(
            "SELECT
                id,
                title,
                slug,
                excerpt,
                published_at,
                is_premium
             FROM news
             ORDER BY id DESC
             LIMIT {$limit}"
        );

        echo json_encode([
            'status' => 'success',
            'data' => $news,
            'meta' => [
                'total' => count($news)
            ]
        ]);

        exit;
    }

    $slug = $action;

    $article = $db->fetch(
        "SELECT *
         FROM news
         WHERE slug = ?
         LIMIT 1",
        [$slug]
    );

    if (!$article) {
        throw new Exception('News not found.');
    }

    echo json_encode([
        'status' => 'success',
        'data' => $article
    ]);

} catch (Throwable $e) {

    http_response_code(404);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}