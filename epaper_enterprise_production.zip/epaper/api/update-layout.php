<?php
// api/update-layout.php

require_once __DIR__ . '/../includes/Database.php';

$db = Database::getInstance()->pdo();

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data[0])) {
    foreach ($data as $d) {
        $db->prepare("UPDATE news SET position_order=? WHERE id=?")
           ->execute([$d['position'], $d['id']]);
    }
    exit;
}

if ($data['type'] === 'span') {
    $db->prepare("UPDATE news SET column_span=? WHERE id=?")
       ->execute([$data['span'], $data['id']]);
}
<?php
require_once '../includes/Database.php';

$db = Database::getInstance()->pdo();

$data = json_decode(file_get_contents("php://input"), true);

if ($data['type'] === 'order') {

    foreach ($data['data'] as $item) {
        $stmt = $db->prepare("UPDATE news SET position_order = ? WHERE id = ?");
        $stmt->execute([$item['position'], $item['id']]);
    }

    echo json_encode(["status" => "order updated"]);
}

/* Column span update */
if ($data['type'] === 'span') {

    $stmt = $db->prepare("UPDATE news SET column_span = ? WHERE id = ?");
    $stmt->execute([$data['span'], $data['id']]);

    echo json_encode(["status" => "span updated"]);
}