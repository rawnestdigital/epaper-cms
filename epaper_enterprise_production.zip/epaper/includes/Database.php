<?php
class Database {
    private static $instance;
    private $pdo;
    private function __construct() {
        $this->pdo = new PDO('sqlite:' . DB_PATH);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }
    public static function getInstance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }
    public function query($sql, $params=[]) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    public function fetch($sql, $params=[]) {
        return $this->query($sql, $params)->fetch();
    }
    public function fetchAll($sql, $params=[]) {
        return $this->query($sql, $params)->fetchAll();
    }
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }
}
<?php

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $dbPath = __DIR__ . '/../database/app.db';

        $this->pdo = new PDO("sqlite:" . $dbPath);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Enable WAL mode
        $this->pdo->exec("PRAGMA journal_mode = WAL;");
        $this->pdo->exec("PRAGMA foreign_keys = ON;");
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function pdo() {
        return $this->pdo;
    }
}
<?php


class Database {


private static $instance;

private PDO $pdo;


private function __construct() {


$this->pdo = new PDO('sqlite:' . DATABASE_PATH);


$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$this->pdo->exec('PRAGMA foreign_keys = ON');

}


public static function getInstance(): self {


if (!self::$instance) {

self::$instance = new self();

}


return self::$instance;

}


public function query(string $sql, array $params = []): PDOStatement {


$stmt = $this->pdo->prepare($sql);


$stmt->execute($params);


return $stmt;

}


public function fetch(string $sql, array $params = []): array|false {

return $this->query($sql, $params)->fetch();

}


public function fetchAll(string $sql, array $params = []): array {

return $this->query($sql, $params)->fetchAll();

}


public function lastInsertId(): string {

return $this->pdo->lastInsertId();

}

}
<?php


class Database {


private static $instance = null;

private $pdo;


private function __construct() {


$this->pdo = new PDO('sqlite:' . DB_PATH);


$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

}


public static function getInstance() {


if (!self::$instance) {

self::$instance = new self();

}


return self::$instance;

}


public function query($sql, $params = []) {


$stmt = $this->pdo->prepare($sql);

$stmt->execute($params);


return $stmt;

}


public function fetch($sql, $params = []) {

return $this->query($sql, $params)->fetch();

}


public function fetchAll($sql, $params = []) {

return $this->query($sql, $params)->fetchAll();

}


public function lastInsertId() {

return $this->pdo->lastInsertId();

}

}


