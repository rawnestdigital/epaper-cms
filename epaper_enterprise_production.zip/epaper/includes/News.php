public function create(array $data): int {

    $this->db->query(
        'INSERT INTO news (
            edition_id,
            category,
            title,
            slug,
            summary,
            content,
            image,
            page_number,
            column_span,
            sort_order,
            coordinate_x,
            coordinate_y,
            block_width,
            block_height,
            author_id,
            status,
            seo_title,
            seo_description
        ) VALUES (
            :edition_id,
            :category,
            :title,
            :slug,
            :summary,
            :content,
            :image,
            :page_number,
            :column_span,
            :sort_order,
            :coordinate_x,
            :coordinate_y,
            :block_width,
            :block_height,
            :author_id,
            :status,
            :seo_title,
            :seo_description
        )',
        $data
    );

    return (int)$this->db->lastInsertId();
}
<?php


class News {


private Database $db;


public function __construct() {

$this->db = Database::getInstance();

}


public function latest(int $limit = 20): array {


return $this->db->fetchAll(

'SELECT * FROM news WHERE status = ? ORDER BY id DESC LIMIT ' . (int)$limit,

['published']

);

}


public function find(string $slug): array|false {


return $this->db->fetch(

'SELECT * FROM news WHERE slug = ? LIMIT 1',

[$slug]

);

}


public function category(string $category): array {


return $this->db->fetchAll(

'SELECT * FROM news WHERE category = ? AND status = ?',

[$category, 'published']

);

}


public function create(array $data): int {


$this->db->query(

'INSERT INTO news (

edition_id,

category,

title,

slug,

summary,

content,

image,

page_number,

coordinate_x,

coordinate_y,

block_width,

}
<?php


class News {


public function latest($limit = 10) {


$db = Database::getInstance();


return $db->fetchAll(

"SELECT * FROM news WHERE status='published' ORDER BY id DESC LIMIT ?",

[$limit]

);

}


public function findBySlug($slug) {


$db = Database::getInstance();


return $db->fetch(

"SELECT * FROM news WHERE slug=? LIMIT 1",

[$slug]

);

}

}


