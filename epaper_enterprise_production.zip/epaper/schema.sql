
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT);
INSERT INTO users(username,password,role) VALUES('admin','$2y$10$abcdefghijklmnopqrstuv','admin');
CREATE TABLE IF NOT EXISTS editions(id INTEGER PRIMARY KEY,title TEXT,pdf_path TEXT,publish_date TEXT);
CREATE TABLE IF NOT EXISTS news(id INTEGER PRIMARY KEY,title TEXT,content TEXT,edition_id INTEGER,is_premium INTEGER DEFAULT 0,sort_order INTEGER DEFAULT 0,column_span INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY,event TEXT,details TEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
