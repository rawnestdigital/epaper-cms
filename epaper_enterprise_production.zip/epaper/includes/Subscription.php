<?php


class Subscription

{

private Database $db;


private const FREE_LIMIT = 5;


public function __construct()

{

$this->db = Database::getInstance();

}


public function getActiveSubscription(int $userId): ?array

{

$subscription = $this->db->fetch(

"SELECT *

FROM subscriptions

WHERE user_id = ?

AND status = 'active'

AND (

expires_at IS NULL

OR expires_at >= datetime('now')

)

ORDER BY id DESC

LIMIT 1",

[$userId]

);


return $subscription ?: null;

}


public function hasPremiumAccess(int $userId): bool

{

$subscription = $this->getActiveSubscription($userId);


if (!$subscription) {

return false;

}


return in_array(

$subscription['plan'],

['premium', 'vip'],

true

);

}


public function checkAccess(int $userId, int $newsId): bool

{

$news = $this->db->fetch(

"SELECT id, is_premium

FROM news

WHERE id = ?

LIMIT 1",

[$newsId]

);


if (!$news) {

return false;

}


if ((int) $news['is_premium'] === 0) {

return true;

}


if ($this->hasPremiumAccess($userId)) {

return true;

}


return $this->consumeFreeView($userId);

}


public function consumeFreeView(int $userId): bool

{

$month = date('Y-m-01');


$usage = $this->db->fetch(

"SELECT *

FROM subscription_usage

WHERE user_id = ?

AND month = ?

LIMIT 1",

[$userId, $month]

);


if (!$usage) {


$this->db->query(

"INSERT INTO subscription_usage

(user_id, month, premium_views)

VALUES (?, ?, 1)",

[$userId, $month]

);


return true;

}

}

