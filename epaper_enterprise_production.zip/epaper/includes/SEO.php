<?php
// includes/SEO.php

final class SEO
{
    public static function meta(string $title, string $desc): void
    {
        echo "<title>$title</title>";
        echo "<meta name='description' content='$desc'>";
    }
}
<?php

class Seo {

    private Settings $settings;

    public function __construct() {

        $this->settings = new Settings();
    }

    public function meta(array $data = []): array {

        $title = $data['seo_title']
            ?? $data['title']
            ?? $this->settings->get('site_name');

        $description = $data['seo_description']
            ?? $this->settings->get('site_tagline');

        $image = !empty($data['image'])
            ? APP_URL . '/storage/uploads/' . $data['image']
            : APP_URL . '/storage/uploads/' . $this->settings->get('site_logo');

        $url = APP_URL . $_SERVER['REQUEST_URI'];

        return [

            'title' => $title,
            'description' => $description,
            'image' => $image,
            'url' => $url
        ];
    }
}