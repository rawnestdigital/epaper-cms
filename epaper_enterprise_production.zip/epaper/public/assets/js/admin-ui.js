const sidebarToggle = document.querySelector('.sidebar-toggle');

const sidebar = document.querySelector('.admin-sidebar');

if(sidebarToggle){

    sidebarToggle.addEventListener('click', () => {

        sidebar.classList.toggle('active');
    });
}

document.querySelectorAll('.delete-action')
.forEach(button => {

    button.addEventListener('click', e => {

        const confirmDelete = confirm('ডিলিট করতে চান?');

        if(!confirmDelete){

            e.preventDefault();
        }
    });
});