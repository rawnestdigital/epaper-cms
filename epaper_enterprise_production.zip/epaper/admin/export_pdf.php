<?php

require_once '../config.php';


header('Content-Type: application/pdf');


// TCPDF / Dompdf integration placeholder


echo 'PDF Export System';

