<?php
// includes/ErrorHandler.php

final class ErrorHandler
{
    public static function register(): void
    {
        set_error_handler(function ($severity, $message, $file, $line) {
            http_response_code(500);
            error_log("Error: $message in $file on line $line");
            exit("System Error");
        });

        set_exception_handler(function ($e) {
            http_response_code(500);
            error_log($e->getMessage());
            exit("Fatal Error");
        });
    }
}