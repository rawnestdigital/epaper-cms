<?php

require_once '../config.php';


header('Content-Type: application/json');


$action = $_GET['action'] ?? '';


switch ($action) {


case 'latest_news':


$news = new News();


echo json_encode($news->latest());


break;


default:


echo json_encode([

'error' => 'Invalid action'

]);

}

