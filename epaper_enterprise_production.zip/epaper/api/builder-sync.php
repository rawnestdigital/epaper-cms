<?php
// api/builder-sync.php

require_once __DIR__ . '/../includes/Security.php';
require_once __DIR__ . '/../includes/Database.php';

Security::startSession();
Security::requireRole(['Admin','Editor']);

header('Content-Type: application/json');

$db = Database::getInstance()->pdo();

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['type'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid payload']);
    exit;
}

/* -------------------------
   SAVE ORDER (DRAG DROP)
-------------------------- */
if ($data['type'] === 'order' && isset($data['items'])) {

    $stmt = $db->prepare("UPDATE news SET position_order=? WHERE id=?");

    foreach ($data['items'] as $item) {
        $stmt->execute([
            (int)$item['position'],
            (int)$item['id']
        ]);
    }

    echo json_encode(['status' => 'order_updated']);
    exit;
}

/* -------------------------
   SAVE COLUMN SPAN
-------------------------- */
if ($data['type'] === 'span') {

    $stmt = $db->prepare("UPDATE news SET column_span=? WHERE id=?");

    $stmt->execute([
        (int)$data['span'],
        (int)$data['id']
    ]);

    echo json_encode(['status' => 'span_updated']);
    exit;
}

/* -------------------------
   SAVE PAGE POSITION
-------------------------- */
if ($data['type'] === 'page') {

    $stmt = $db->prepare("UPDATE news SET page_number=? WHERE id=?");

    $stmt->execute([
        (int)$data['page'],
        (int)$data['id']
    ]);

    echo json_encode(['status' => 'page_updated']);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'Unknown operation']);