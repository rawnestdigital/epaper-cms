<?php

class Validator {

    private array $errors = [];

    public function required($value, string $field) {

        if(empty($value)) {

            $this->errors[$field] = "$field required";
        }

        return $this;
    }

    public function email($value, string $field) {

        if(!filter_var($value, FILTER_VALIDATE_EMAIL)) {

            $this->errors[$field] = "$field invalid email";
        }

        return $this;
    }

    public function min($value, int $len, string $field) {

        if(strlen($value) < $len) {

            $this->errors[$field] = "$field minimum $len chars";
        }

        return $this;
    }

    public function fails(): bool {

        return !empty($this->errors);
    }

    public function errors(): array {

        return $this->errors;
    }
}