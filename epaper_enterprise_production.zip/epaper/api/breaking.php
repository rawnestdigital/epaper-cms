<?php
// api/breaking.php

require_once __DIR__ . '/../includes/Database.php';

header('Content-Type: application/json');

$db = Database::getInstance()->pdo();

$stmt = $db->query("
    SELECT title
    FROM news
    WHERE status='Published'
    AND (title LIKE '%Breaking%' OR title LIKE '%Urgent%' OR title LIKE '%ব্রেকিং%')
    ORDER BY id DESC
    LIMIT 5
");

echo json_encode($stmt->fetchAll(PDO::FETCH_COLUMN));
<?php
require_once '../includes/Database.php';

$db = Database::getInstance()->pdo();

$stmt = $db->query("
    SELECT title FROM news 
    WHERE status='Published' 
    AND (title LIKE '%Urgent%' OR title LIKE '%ব্রেকিং%')
    ORDER BY id DESC
    LIMIT 5
");

$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$titles = array_map(fn($n) => $n['title'], $items);

echo json_encode($titles);