<?php


class PaywallMiddleware

{

public static function canAccessPremium(int $newsId): bool

{

if (empty($_SESSION['user']['id'])) {

return false;

}


$subscription = new Subscription();


return $subscription->checkAccess(

(int) $_SESSION['user']['id'],

$newsId

);

}


public static function enforce(int $newsId): void

{

if (!self::canAccessPremium($newsId)) {


http_response_code(403);


include BASE_PATH . '/templates/paywall.php';


exit;

}

}

}

