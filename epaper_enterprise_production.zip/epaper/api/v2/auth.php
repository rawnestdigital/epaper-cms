<?php

$db = Database::getInstance();

$input = json_decode(
    file_get_contents('php://input'),
    true
);

$action = $segments[1] ?? '';

try {

    if ($method !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    if ($action === 'login') {

        $email = trim($input['email'] ?? '');
        $password = trim($input['password'] ?? '');

        $user = $db->fetch(
            "SELECT *
             FROM users
             WHERE email = ?
             LIMIT 1",
            [$email]
        );

        if (
            !$user ||
            !password_verify(
                $password,
                $user['password']
            )
        ) {

            AuditLogger::log(
                'login_failed',
                $email
            );

            throw new Exception('Invalid credentials.');
        }

        $token = JWT::encode([
            'id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role']
        ]);

        AuditLogger::log(
            'login_success',
            $email
        );

        echo json_encode([
            'status' => 'success',
            'data' => [
                'token' => $token,
                'user' => [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ]
            ]
        ]);

        exit;
    }

    if ($action === 'register') {

        $name = trim($input['name'] ?? '');
        $email = trim($input['email'] ?? '');
        $password = trim($input['password'] ?? '');

        if (
            empty($name) ||
            empty($email) ||
            empty($password)
        ) {
            throw new Exception('All fields are required.');
        }

        $exists = $db->fetch(
            "SELECT id
             FROM users
             WHERE email = ?
             LIMIT 1",
            [$email]
        );

        if ($exists) {
            throw new Exception('Email already exists.');
        }

        $hashedPassword = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $db->query(
            "INSERT INTO users
             (name, email, password, role)
             VALUES (?, ?, ?, ?)",
            [
                $name,
                $email,
                $hashedPassword,
                'reporter'
            ]
        );

        AuditLogger::log(
            'user_registered',
            $email
        );

        echo json_encode([
            'status' => 'success',
            'message' => 'Registration successful.'
        ]);

        exit;
    }

    throw new Exception('Invalid auth route.');

} catch (Throwable $e) {

    http_response_code(400);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}