<?php


class ImagePipeline {


private array $allowed = [

'image/jpeg',

'image/png',

'image/webp'

];


public function upload(array $file): string {


if (!isset($file['tmp_name'])) {

throw new Exception('Upload failed');

}


if (!in_array($file['type'], $this->allowed)) {

throw new Exception('Invalid image type');

}


if ($file['size'] > 10485760) {

throw new Exception('File too large');

}


$extension = pathinfo($file['name'], PATHINFO_EXTENSION);


$filename = uniqid('news_', true) . '.' . strtolower($extension);


$destination = UPLOAD_PATH . '/' . $filename;


if (!move_uploaded_file($file['tmp_name'], $destination)) {

throw new Exception('Unable to upload');

}


return $filename;

}

}
<?php


class ImagePipeline {


public function upload($file) {


$name = time() . '_' . basename($file['name']);


$target = UPLOAD_PATH . '/' . $name;


move_uploaded_file($file['tmp_name'], $target);


$optimizer = new ImageOptimizer();


$optimizer->optimize($target, $target);


return $name;

}

}



