<?php
$editionId = $_GET['date'] ?? date('Y-m-d');
$page = (int)($_GET['page'] ?? 1);
$layout = new LayoutBuilder();
$newsItems = $layout->getEditionLayout($editionId, $page);
?>
<div class="epaper-grid">
<?php foreach($newsItems as $item): ?>
<div class="grid-item" style="grid-column: span <?= $item['column_span'] ?>" data-news-id="<?= $item['id'] ?>">
    <img src="<?= asset('uploads/'.$item['image']) ?>" alt="">
    <h3><?= e($item['title']) ?></h3>
</div>
<?php endforeach; ?>
</div>
<!-- পেজিনেশন -->
<div class="pagination"><?php for($i=1;$i<=6;$i++): ?><a href="?date=<?= $editionId ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor; ?></div>
<?php
// templates/epaper-view.php

require_once __DIR__ . '/../includes/Database.php';

$db = Database::getInstance()->pdo();

$page = $_GET['page'];

$stmt = $db->prepare("SELECT * FROM news WHERE page_number=? AND status='Published'");
$stmt->execute([$page]);
$news = $stmt->fetchAll();
?>

<div class="epaper-container">

<?php foreach($news as $i=>$n): ?>

<div class="news-item col-<?= $n['column_span'] ?> <?= $i==0?'hero-news':'' ?>">

<h2><?= $n['title'] ?></h2>

<?php if($n['image']): ?>
<img src="/uploads/news/<?= $n['image'] ?>">
<?php endif; ?>

</div>

<?php endforeach; ?>

</div>
<?php foreach ($news as $index => $n): ?>

    <?php 
        $isHero = ($index === 0); // AI top-ranked item becomes hero
    ?>

    <div class="news-item col-<?= $n['column_span'] ?> <?= $isHero ? 'hero-news' : '' ?>"
         data-id="<?= $n['id'] ?>"
         data-title="<?= htmlspecialchars($n['title']) ?>"
         data-body="<?= htmlspecialchars($n['body']) ?>"
         data-image="/uploads/news/<?= $n['image'] ?>"
         data-score="<?= $n['position_order'] ?>">

        <div class="news-title">
            <?= htmlspecialchars($n['title']) ?>
        </div>

        <?php if ($n['image']): ?>
            <img src="/uploads/news/<?= $n['image'] ?>">
        <?php endif; ?>

        <div class="news-body">
            <?= substr(strip_tags($n['body']), 0, 150) ?>...
        </div>

    </div>

<?php endforeach; ?>
<button onclick="window.print()">🖨️ Print / Save PDF</button>
<?php
require_once '../includes/Database.php';
$db = Database::getInstance()->pdo();

$page = $_GET['page'] ?? 1;

$stmt = $db->prepare("SELECT * FROM news WHERE page_number = ?");
$stmt->execute([$page]);
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>

<div class="epaper-container">

<?php foreach ($news as $n): ?>
    <div class="news-item col-<?= $n['column_span'] ?>"
         data-id="<?= $n['id'] ?>"
         data-title="<?= htmlspecialchars($n['title']) ?>"
         data-body="<?= htmlspecialchars($n['body']) ?>"
         data-image="/uploads/news/<?= $n['image'] ?>">

        <div class="news-title"><?= htmlspecialchars($n['title']) ?></div>

        <?php if ($n['image']): ?>
            <img src="/uploads/news/<?= $n['image'] ?>" style="width:100%;">
        <?php endif; ?>

        <div class="news-body">
            <?= substr(strip_tags($n['body']), 0, 120) ?>...
        </div>

    </div>
<?php endforeach; ?>

</div>

<!-- MODAL -->
<div id="newsModal" class="modal">
    <div class="modal-content">

        <span class="close">&times;</span>

        <div class="tabs">
            <button onclick="showView('text')">টেক্সট</button>
            <button onclick="showView('image')">ইমেজ</button>
        </div>

        <h2 id="modalTitle"></h2>

        <div id="textView"></div>

        <img id="imageView" style="max-width:100%; display:none;">

        <div class="share">
            <button onclick="shareWA()">WhatsApp</button>
            <button onclick="shareFB()">Facebook</button>
            <button onclick="copyLink()">Copy Link</button>
        </div>

    </div>
</div>

<script src="/assets/js/viewer.js"></script>

<?php include 'footer.php'; ?>
<?php
require_once '../includes/Database.php';

$db = Database::getInstance()->pdo();

$page = $_GET['page'] ?? 1;

$stmt = $db->prepare("SELECT * FROM news WHERE page_number = ?");
$stmt->execute([$page]);
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../assets/css/epaper.css">

<div class="epaper-container">

<?php foreach ($news as $n): ?>
    <div class="news-item col-<?= $n['column_span'] ?>">

        <div class="news-title"><?= htmlspecialchars($n['title']) ?></div>

        <?php if ($n['image']): ?>
            <img src="../uploads/news/<?= $n['image'] ?>" style="width:100%;">
        <?php endif; ?>

        <div><?= nl2br(htmlspecialchars($n['body'])) ?></div>

    </div>
<?php endforeach; ?>

</div>
<?php
require_once BASE_PATH . '/bootstrap.php';

$news = new News();

$page = isset($_GET['page'])
    ? max(1, min(6, (int)$_GET['page']))
    : 1;

$date = $_GET['date'] ?? date('Y-m-d');

$items = $news->db->fetchAll(
    "SELECT * FROM news
     WHERE page_number = ?
     AND DATE(created_at)=?
     AND status='published'
     ORDER BY sort_order ASC",
    [$page, $date]
);
?>

<link
    rel="stylesheet"
    href="<?= asset('css/epaper-ui.css') ?>"
>

<div class="epaper-wrapper">

    <div class="epaper-topbar">

        <div class="epaper-brand">

            <h1>দৈনিক দেশান্তর</h1>

            <p><?= date('d F Y', strtotime($date)) ?></p>

        </div>

    </div>

    <div class="epaper-pagination">

        <?php for($i=1; $i<=6; $i++): ?>

            <a
                href="?page=<?= $i ?>&date=<?= $date ?>"
                class="<?= $page === $i ? 'active' : '' ?>"
            >
                <?= $i ?>
            </a>

        <?php endfor; ?>

    </div>

    <div class="epaper-grid">

        <?php foreach($items as $item): ?>

            <article
                class="news-block"
                style="grid-column: span <?= (int)$item['column_span'] ?>;"
                data-id="<?= $item['id'] ?>"
                data-title="<?= e($item['title']) ?>"
                data-image="/storage/uploads/<?= e($item['image']) ?>"
                data-content="<?= e($item['content']) ?>"
            >

                <div class="news-image">

                    <img
                        src="/storage/uploads/<?= e($item['image']) ?>"
                        alt="<?= e($item['title']) ?>"
                        loading="lazy"
                    >

                </div>

                <div class="news-content">

                    <h2>
                        <?= e($item['title']) ?>
                    </h2>

                    <p>
                        <?= mb_substr(strip_tags($item['summary']),0,180) ?>
                    </p>

                </div>

            </article>

        <?php endforeach; ?>

    </div>

</div>

<div id="newsModal" class="news-modal">

    <div class="modal-container">

        <div class="modal-header">

            <div class="modal-actions">

                <button data-view="image">
                    ইমেজ ভিউ
                </button>

                <button data-view="text">
                    টেক্সট ভিউ
                </button>

                <button data-view="full">
                    ফুল পেজ ভিউ
                </button>

                <button id="downloadBtn">
                    ডাউনলোড
                </button>

            </div>

            <button id="closeModal">
                ×
            </button>

        </div>

        <div class="modal-body">

            <div class="modal-image-view active">

                <img
                    id="modalImage"
                    src=""
                    alt=""
                >

            </div>

            <div class="modal-text-view">

                <h1 id="modalTitle"></h1>

                <div id="modalContent"></div>

            </div>

            <div class="modal-full-view">

                <div class="full-layout-preview">

                    <iframe
                        src=""
                        id="fullPageFrame"
                    ></iframe>

                </div>

            </div>

        </div>

        <div class="share-bar">

            <a id="shareWhatsapp">WhatsApp</a>

            <a id="shareFacebook">Facebook</a>

            <a id="shareX">X</a>

            <a id="shareEmail">Email</a>

            <button id="copyLink">
                Copy Link
            </button>

        </div>

    </div>

</div>

<script src="<?= asset('js/epaper-engine.js') ?>"></script>
<?php

$news = new News();

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

$items = $news->byPage($page);
?>

<div class="epaper-grid">

    <?php foreach ($items as $item): ?>

        <article
            class="news-block"
            style="
                grid-column: span <?= (int)$item['column_span'] ?>;
            "
        >

            <img
                src="/storage/uploads/<?= $item['image'] ?>"
                alt="<?= e($item['title']) ?>"
            >

            <h2><?= e($item['title']) ?></h2>

        </article>

    <?php endforeach; ?>

</div>