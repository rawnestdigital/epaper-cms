<?php

class Response {

    public static function json($data, int $code = 200) {

        http_response_code($code);

        header('Content-Type: application/json');

        echo json_encode($data);

        exit;
    }

    public static function success($data = [], int $code = 200) {

        self::json([
            'status' => 'success',
            'data' => $data
        ], $code);
    }

    public static function error(string $msg, int $code = 400) {

        self::json([
            'status' => 'error',
            'message' => $msg
        ], $code);
    }
}