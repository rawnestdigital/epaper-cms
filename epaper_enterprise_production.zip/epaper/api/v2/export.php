<?php

require_once '../../bootstrap.php';

require_once BASE_PATH . '/vendor/autoload.php';

header('Content-Type: application/json');

try {

    $editionId = (int) ($_GET['edition_id'] ?? 0);

    if ($editionId <= 0) {
        throw new Exception('Invalid edition ID.');
    }

    $authorized = false;

    if (isset($_SESSION['user'])) {
        $authorized = true;
    }

    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    if (!$authorized && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {

        if (class_exists('JWT')) {

            $payload = JWT::decode($matches[1]);

            if (!empty($payload['id'])) {
                $authorized = true;
            }
        }
    }

    if (!$authorized) {

        http_response_code(401);

        echo json_encode([
            'status' => 'error',
            'message' => 'Unauthorized.'
        ]);

        exit;
    }

    $db = Database::getInstance();

    $edition = $db->fetch(
        "SELECT pdf_path
         FROM editions
         WHERE id = ?
         LIMIT 1",
        [$editionId]
    );

    $pdfPath = '';

    if (
        $edition &&
        !empty($edition['pdf_path']) &&
        file_exists(STORAGE_PATH . $edition['pdf_path'])
    ) {

        $pdfPath = STORAGE_PATH . $edition['pdf_path'];

    } else {

        $generator = new PdfGenerator();

        $pdfPath = $generator->generateEditionPdf($editionId);
    }

    if (!file_exists($pdfPath)) {
        throw new Exception('PDF file not found.');
    }

    AuditLogger::log(
        'pdf_downloaded',
        'Edition ID: ' . $editionId
    );

    if (isset($_GET['download'])) {

        header('Content-Type: application/pdf');

        header(
            'Content-Disposition: attachment; filename="' .
            basename($pdfPath) .
            '"'
        );

        header('Content-Length: ' . filesize($pdfPath));

        readfile($pdfPath);

        exit;
    }

    echo json_encode([
        'status' => 'success',
        'data' => [
            'download_url' =>
                APP_URL .
                '/api/v2/export.php?edition_id=' .
                $editionId .
                '&download=1',

            'pdf_url' =>
                APP_URL .
                '/storage/pdfs/' .
                basename($pdfPath)
        ]
    ]);

} catch (Throwable $e) {

    http_response_code(400);

    AuditLogger::log(
        'pdf_export_api_failed',
        $e->getMessage()
    );

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}