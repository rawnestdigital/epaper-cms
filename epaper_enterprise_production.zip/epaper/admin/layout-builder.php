<?php

require_once '../bootstrap.php';

$security->requireLogin();

$editionId = (int) ($_GET['edition_id'] ?? 0);

if ($editionId <= 0) {
    die('Invalid edition.');
}

$builder = new LayoutBuilder();

$layout = $builder->getEditionLayout($editionId);

$csrf = $security->csrfToken();
?>

<!DOCTYPE html>
<html lang="bn">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Layout Builder</title>

<link rel="stylesheet" href="../public/assets/css/app.css">

<style>

body{
    margin:0;
    padding:20px;
    background:#f5f5f5;
    font-family:'Hind Siliguri','SolaimanLipi',sans-serif;
}

.builder-toolbar{
    display:flex;
    flex-wrap:wrap;
    gap:10px;
    margin-bottom:20px;
}

.builder-grid{
    display:grid;
    grid-template-columns:repeat(12,1fr);
    gap:12px;
}

.news-block{
    background:#fff;
    border-radius:10px;
    padding:12px;
    border:1px solid #ddd;
    cursor:move;
    box-shadow:0 2px 6px rgba(0,0,0,.08);
}

.news-block img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:8px;
}

.news-title{
    margin-top:10px;
    font-size:18px;
    line-height:1.5;
    font-weight:700;
}

.block-meta{
    margin-top:10px;
}

.block-meta select{
    width:100%;
    padding:8px;
    border-radius:6px;
}

button{
    background:#111827;
    color:#fff;
    border:none;
    padding:12px 18px;
    border-radius:8px;
    cursor:pointer;
}

.preview-box{
    margin-top:25px;
    background:#fff;
    border-radius:12px;
    padding:15px;
}

@media(max-width:768px){

    .builder-grid{
        grid-template-columns:1fr;
    }

    .news-block{
        grid-column:span 1 !important;
    }

}

</style>

</head>

<body>

<div class="builder-toolbar">

    <button id="saveLayoutBtn">
        Save Layout
    </button>

</div>

<div id="builderGrid" class="builder-grid">

<?php foreach ($layout as $item): ?>

<div
    class="news-block"
    data-id="<?= (int) $item['id'] ?>"
    style="grid-column: span <?= (int) $item['column_span'] ?>;"
>

    <?php if (!empty($item['image'])): ?>

        <img
            src="<?= e(APP_URL . '/storage/uploads/' . $item['image']) ?>"
            alt="<?= e($item['title']) ?>"
        >

    <?php endif; ?>

    <div class="news-title">
        <?= e($item['title']) ?>
    </div>

    <div class="block-meta">

        <label>Column Span</label>

        <select class="column-span">

            <?php for ($i = 1; $i <= 12; $i++): ?>

                <option
                    value="<?= $i ?>"
                    <?= ((int)$item['column_span'] === $i) ? 'selected' : '' ?>
                >
                    <?= $i ?> Column
                </option>

            <?php endfor; ?>

        </select>

    </div>

</div>

<?php endforeach; ?>

</div>

<div class="preview-box">
    <strong>লাইভ প্রিভিউ সক্রিয়</strong>
</div>

<script>
window.layoutBuilderConfig = {
    editionId: <?= $editionId ?>,
    csrfToken: '<?= e($csrf) ?>',
    saveUrl: '../api/v2/layout.php'
};
</script>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>

<script src="../public/assets/js/layout-builder.js"></script>

</body>
</html>