# Enterprise ePaper CMS

Default Admin:
- user: admin
- pass: admin123

Run:
```bash
bash deploy.sh
```
