<?php
// api/workflow.php

require_once __DIR__ . '/../includes/Security.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Workflow.php';

Security::startSession();
Security::requireRole(['Admin','Editor']);

header('Content-Type: application/json');

$db = Database::getInstance()->pdo();
$wf = new Workflow($db);

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['action'], $data['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
    exit;
}

$id = (int)$data['id'];
$action = $data['action'];

switch ($action) {

    case 'publish':
        $wf->setStatus($id, 'Published');
        break;

    case 'review':
        $wf->setStatus($id, 'Pending');
        break;

    case 'draft':
        $wf->setStatus($id, 'Draft');
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
        exit;
}

echo json_encode(['status' => 'ok']);