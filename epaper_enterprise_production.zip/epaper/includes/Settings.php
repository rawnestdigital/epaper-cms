<?php
// includes/Settings.php

final class Settings
{
    public function __construct(private PDO $db) {}

    public function get(string $key): ?string
    {
        $stmt = $this->db->prepare("SELECT value FROM settings WHERE key=?");
        $stmt->execute([$key]);
        return $stmt->fetchColumn() ?: null;
    }

    public function set(string $key, string $value): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO settings (key, value)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
        ");

        return $stmt->execute([$key, $value]);
    }

    public function all(): array
    {
        return $this->db->query("SELECT key,value FROM settings")
            ->fetchAll(PDO::FETCH_KEY_PAIR);
    }
}
<?php
require_once __DIR__ . '/Database.php';

class Settings {

    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->pdo();
    }

    public function get($key) {
        $stmt = $this->db->prepare("SELECT value FROM settings WHERE key = ?");
        $stmt->execute([$key]);
        return $stmt->fetchColumn();
    }

    public function set($key, $value) {
        $stmt = $this->db->prepare("
            INSERT INTO settings (key, value)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
        ");
        return $stmt->execute([$key, $value]);
    }

    public function all() {
        $stmt = $this->db->query("SELECT * FROM settings");
        return $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    }
}
<?php

class Settings {

    private Database $db;

    private array $cache = [];

    public function __construct() {

        $this->db = Database::getInstance();

        $this->load();
    }

    private function load(): void {

        $rows = $this->db->fetchAll(
            "SELECT setting_key, setting_value FROM settings"
        );

        foreach($rows as $row){

            $this->cache[$row['setting_key']] = $row['setting_value'];
        }
    }

    public function get(string $key, string $default=''): string {

        return $this->cache[$key] ?? $default;
    }

    public function set(string $key, string $value): bool {

        $exists = $this->db->fetch(
            "SELECT id FROM settings WHERE setting_key=? LIMIT 1",
            [$key]
        );

        if($exists){

            $this->db->query(
                "UPDATE settings
                 SET setting_value=?,
                 updated_at=CURRENT_TIMESTAMP
                 WHERE setting_key=?",
                [$value, $key]
            );

        } else {

            $this->db->query(
                "INSERT INTO settings
                (setting_key, setting_value)
                VALUES(?,?)",
                [$key, $value]
            );
        }

        $this->cache[$key] = $value;

        return true;
    }

    public function all(): array {

        return $this->cache;
    }
}