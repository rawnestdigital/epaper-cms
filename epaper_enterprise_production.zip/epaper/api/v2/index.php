<?php

require_once '../../bootstrap.php';

header('Content-Type: application/json');

$uri = parse_url(
    $_SERVER['REQUEST_URI'],
    PHP_URL_PATH
);

$method = $_SERVER['REQUEST_METHOD'];

$base = '/api/v2';

$route = str_replace($base, '', $uri);

$route = trim($route, '/');

$segments = explode('/', $route);

try {

    if ($segments[0] === 'auth') {

        require 'auth.php';
        exit;
    }

    if ($segments[0] === 'news') {

        require 'news.php';
        exit;
    }

    if ($segments[0] === 'editions') {

        require 'editions.php';
        exit;
    }

    if ($segments[0] === 'subscribe') {

        require 'subscribe.php';
        exit;
    }

    throw new Exception('API endpoint not found.');

} catch (Throwable $e) {

    http_response_code(404);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}