<?php

use Dompdf\Dompdf;
use Dompdf\Options;

class PdfGenerator
{
    private Database $db;
    private LayoutBuilder $layoutBuilder;

    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->layoutBuilder = new LayoutBuilder();

        if (!is_dir(STORAGE_PATH . '/pdfs')) {
            mkdir(STORAGE_PATH . '/pdfs', 0755, true);
        }
    }

    public function generateEditionPdf(int $editionId): string
    {
        try {

            $edition = $this->db->fetch(
                "SELECT * FROM editions WHERE id = ? LIMIT 1",
                [$editionId]
            );

            if (!$edition) {
                throw new Exception('Edition not found.');
            }

            $layout = $this->layoutBuilder->getEditionLayout($editionId);

            if (empty($layout)) {
                throw new Exception('No news blocks found.');
            }

            $html = $this->buildHtml($edition, $layout);

            $options = new Options();

            $options->set('isRemoteEnabled', true);
            $options->set('defaultFont', 'HindSiliguri');

            $dompdf = new Dompdf($options);

            $dompdf->loadHtml($html, 'UTF-8');

            $dompdf->setPaper('A4', 'portrait');

            $dompdf->render();

            $output = $dompdf->output();

            $relativePath = '/pdfs/edition_' . $editionId . '.pdf';

            $fullPath = STORAGE_PATH . $relativePath;

            file_put_contents($fullPath, $output);

            $this->db->query(
                "UPDATE editions
                 SET pdf_path = ?
                 WHERE id = ?",
                [$relativePath, $editionId]
            );

            AuditLogger::log(
                'pdf_generated',
                'Edition ID: ' . $editionId
            );

            return $fullPath;

        } catch (Throwable $e) {

            AuditLogger::log(
                'pdf_generation_failed',
                $e->getMessage()
            );

            throw new Exception(
                'PDF generation failed.'
            );
        }
    }

    private function buildHtml(array $edition, array $layout): string
    {
        $title = e($edition['title']);

        $publishDate = !empty($edition['publish_date'])
            ? e($edition['publish_date'])
            : date('Y-m-d');

        $fontPath = BASE_PATH . '/public/assets/fonts/HindSiliguri-Regular.ttf';

        $html = '
        <!DOCTYPE html>
        <html lang="bn">
        <head>
            <meta charset="UTF-8">

            <style>

                @font-face{
                    font-family:"HindSiliguri";
                    src:url("' . $fontPath . '") format("truetype");
                }

                body{
                    font-family:"HindSiliguri", sans-serif;
                    margin:0;
                    padding:20px;
                    color:#111827;
                    font-size:14px;
                    line-height:1.7;
                }

                .header{
                    text-align:center;
                    margin-bottom:30px;
                    border-bottom:2px solid #ddd;
                    padding-bottom:15px;
                }

                .header h1{
                    margin:0;
                    font-size:30px;
                }

                .header p{
                    margin-top:8px;
                    color:#666;
                }

                .grid{
                    width:100%;
                    display:table;
                }

                .block{
                    border:1px solid #ddd;
                    border-radius:8px;
                    padding:15px;
                    margin-bottom:20px;
                    page-break-inside:avoid;
                }

                .block img{
                    width:100%;
                    height:auto;
                    border-radius:6px;
                    margin-bottom:10px;
                }

                .title{
                    font-size:20px;
                    font-weight:bold;
                    margin-bottom:12px;
                }

                .content{
                    font-size:14px;
                }

            </style>

        </head>

        <body>

            <div class="header">
                <h1>' . $title . '</h1>
                <p>প্রকাশের তারিখ: ' . $publishDate . '</p>
            </div>

            <div class="grid">
        ';

        foreach ($layout as $item) {

            $newsTitle = e($item['title']);

            $content = !empty($item['content'])
                ? nl2br(e(strip_tags($item['content'])))
                : '';

            $imageHtml = '';

            if (!empty($item['image'])) {

                $imagePath = STORAGE_PATH . '/uploads/' . $item['image'];

                if (file_exists($imagePath)) {

                    $imageHtml = '
                        <img src="' . $imagePath . '" alt="' . $newsTitle . '">
                    ';
                }
            }

            $html .= '
                <div class="block">

                    ' . $imageHtml . '

                    <div class="title">
                        ' . $newsTitle . '
                    </div>

                    <div class="content">
                        ' . $content . '
                    </div>

                </div>
            ';
        }

        $html .= '
            </div>

        </body>
        </html>
        ';

        return $html;
    }
}