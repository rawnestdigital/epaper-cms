<?php

require_once '../bootstrap.php';

require_once BASE_PATH . '/vendor/autoload.php';

$security->requireLogin();

$db = Database::getInstance();

$csrf = $security->csrfToken();

$message = '';

$downloadUrl = '';

try {

    $editions = $db->fetchAll(
        "SELECT id, title, publish_date, pdf_path
         FROM editions
         ORDER BY publish_date DESC"
    );

} catch (Throwable $e) {

    $editions = [];

    AuditLogger::log(
        'edition_fetch_failed',
        $e->getMessage()
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        if (!$security->validateCsrf($_POST['csrf_token'] ?? '')) {
            throw new Exception('Invalid CSRF token.');
        }

        $editionId = (int) ($_POST['edition_id'] ?? 0);

        if ($editionId <= 0) {
            throw new Exception('Invalid edition.');
        }

        $generator = new PdfGenerator();

        $path = $generator->generateEditionPdf($editionId);

        $downloadUrl = APP_URL .
            '/storage/pdfs/' .
            basename($path);

        $message = 'PDF generated successfully.';

    } catch (Throwable $e) {

        $message = $e->getMessage();

        AuditLogger::log(
            'admin_pdf_generation_failed',
            $e->getMessage()
        );
    }
}
?>

<!DOCTYPE html>
<html lang="bn">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>ePaper PDF Export</title>

<style>

body{
    margin:0;
    padding:20px;
    background:#f5f5f5;
    font-family:'Hind Siliguri','SolaimanLipi',sans-serif;
}

.container{
    max-width:720px;
    margin:auto;
    background:#fff;
    border-radius:12px;
    padding:24px;
    box-shadow:0 2px 10px rgba(0,0,0,.08);
}

h1{
    margin-top:0;
}

.form-group{
    margin-bottom:20px;
}

label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

select{
    width:100%;
    padding:12px;
    border-radius:8px;
    border:1px solid #ccc;
}

button{
    background:#111827;
    color:#fff;
    border:none;
    padding:14px 18px;
    border-radius:8px;
    cursor:pointer;
    width:100%;
}

.message{
    margin-bottom:20px;
    padding:14px;
    border-radius:8px;
    background:#eef2ff;
}

.download-link{
    display:inline-block;
    margin-top:12px;
    color:#2563eb;
    text-decoration:none;
    font-weight:600;
}

@media(max-width:768px){

    .container{
        padding:16px;
    }

}

</style>

</head>

<body>

<div class="container">

    <h1>ePaper PDF Export</h1>

    <?php if ($message): ?>

        <div class="message">
            <?= e($message) ?>
        </div>

    <?php endif; ?>

    <form method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e($csrf) ?>"
        >

        <div class="form-group">

            <label>
                Edition নির্বাচন করুন
            </label>

            <select name="edition_id" required>

                <option value="">
                    নির্বাচন করুন
                </option>

                <?php foreach ($editions as $edition): ?>

                    <option value="<?= (int) $edition['id'] ?>">

                        <?= e($edition['title']) ?>

                        (<?= e($edition['publish_date']) ?>)

                    </option>

                <?php endforeach; ?>

            </select>

        </div>

        <button type="submit">
            Generate PDF
        </button>

    </form>

    <?php if ($downloadUrl): ?>

        <a
            class="download-link"
            href="<?= e($downloadUrl) ?>"
            target="_blank"
        >
            Download Generated PDF
        </a>

    <?php endif; ?>

</div>

</body>
</html>