<?php

require_once '../../bootstrap.php';

header('Content-Type: application/json');

$security->requireLogin();

try {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    $csrf = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

    if (!$security->validateCsrf($csrf)) {
        throw new Exception('CSRF validation failed.');
    }

    $payload = json_decode(file_get_contents('php://input'), true);

    if (!$payload) {
        throw new Exception('Invalid JSON payload.');
    }

    $editionId = (int) ($payload['edition_id'] ?? 0);

    $blocks = $payload['blocks'] ?? [];

    if ($editionId <= 0) {
        throw new Exception('Invalid edition.');
    }

    $builder = new LayoutBuilder();

    $builder->saveLayout($editionId, $blocks);

    echo json_encode([
        'status' => 'success',
        'message' => 'Layout saved successfully.'
    ]);

} catch (Throwable $e) {

    http_response_code(400);

    AuditLogger::log(
        'layout_api_error',
        $e->getMessage()
    );

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}