<?php require 'bootstrap.php'; include BASE_PATH.'/templates/single-news.php';
<?php

require_once 'bootstrap.php';

$newsModel = new News();

$slug = $_GET['slug'] ?? '';

$article = $newsModel->find($slug);

if(!$article){

    http_response_code(404);

    require BASE_PATH . '/templates/404.php';

    exit;
}

$metaData = $article;

require BASE_PATH . '/templates/header.php';
?>

<main class="single-news-wrapper">

    <article class="single-news-card">

        <div class="single-news-image">

            <img
                src="/storage/uploads/<?= e($article['image']) ?>"
                alt="<?= e($article['title']) ?>"
            >

        </div>

        <div class="single-news-content">

            <div class="single-meta">

                <span>
                    <?= bn_date($article['created_at']) ?>
                </span>

                <span>
                    <?= e($article['category']) ?>
                </span>

            </div>

            <h1>
                <?= e($article['title']) ?>
            </h1>

            <div class="single-body">

                <?= nl2br($article['content']) ?>

            </div>

        </div>

    </article>

</main>

<?php
require BASE_PATH . '/templates/footer.phphp
<?php

require_once 'config.php';


$slug = $_GET['slug'] ?? '';


$news = new News();

$post = $news->findBySlug($slug);


if (!$post) {

die('News not found');

}

?>


<!DOCTYPE html>

<html>

<head>

<title><?= $post['title'] ?></title>

</head>

<body>


<h1><?= htmlspecialchars($post['title']) ?></h1>


<div>

<?= $post['content'] ?>

</div>


</body>

</html>

