<?php
// includes/BootstrapCheck.php

final class BootstrapCheck
{
    public static function run(): void
    {
        $required = [
            'PDO' => extension_loaded('pdo'),
            'SQLite' => extension_loaded('pdo_sqlite'),
            'Session' => function_exists('session_start')
        ];

        foreach ($required as $key => $ok) {
            if (!$ok) {
                http_response_code(500);
                exit("Missing requirement: " . $key);
            }
        }
    }
}