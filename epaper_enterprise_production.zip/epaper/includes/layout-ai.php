<?php
require_once __DIR__ . '/Database.php';

class LayoutAI {

    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->pdo();
    }

    /**
     * Fetch published news for a page
     */
    public function getPageNews($page) {
        $stmt = $this->db->prepare("
            SELECT * FROM news
            WHERE page_number = ? AND status = 'Published'
        ");
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * AI PRIORITY SCORE ENGINE
     * Simulates newsroom editor judgment
     */
    private function score($news) {

        $score = 0;

        // Rule 1: Title length (short headlines = higher priority)
        $score += max(0, 100 - strlen($news['title']));

        // Rule 2: Breaking keywords boost
        $keywords = ['ব্রেকিং', 'Breaking', 'Urgent', 'জরুরি'];
        foreach ($keywords as $k) {
            if (stripos($news['title'], $k) !== false) {
                $score += 80;
            }
        }

        // Rule 3: Image presence
        if (!empty($news['image'])) {
            $score += 40;
        }

        // Rule 4: Column importance (existing editorial hint)
        $score += $news['column_span'] * 5;

        return $score;
    }

    /**
     * AI SORTING ENGINE (PAGE COMPOSER)
     */
    public function autoLayoutPage($page) {

        $news = $this->getPageNews($page);

        // Step 1: score each news
        foreach ($news as &$n) {
            $n['ai_score'] = $this->score($n);
        }

        // Step 2: sort by AI score
        usort($news, function($a, $b) {
            return $b['ai_score'] <=> $a['ai_score'];
        });

        // Step 3: assign new layout order safely
        $order = 1;

        foreach ($news as $item) {

            $stmt = $this->db->prepare("
                UPDATE news 
                SET position_order = ?
                WHERE id = ?
            ");

            $stmt->execute([$order, $item['id']]);

            $order++;
        }

        return $news;
    }

    /**
     * FRONT PAGE GENERATOR (12-column smart packing)
     */
    public function generateSmartGrid($page) {

        $news = $this->autoLayoutPage($page);

        $grid = [];

        $columnCursor = 1;
        $row = 1;

        foreach ($news as $item) {

            // If overflow, move to next row
            if ($columnCursor + $item['column_span'] > 12) {
                $row++;
                $columnCursor = 1;
            }

            $grid[] = [
                'id' => $item['id'],
                'row' => $row,
                'col_start' => $columnCursor,
                'col_span' => $item['column_span']
            ];

            $columnCursor += $item['column_span'];
        }

        return $grid;
    }
}