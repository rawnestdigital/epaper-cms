<?php

$db = Database::getInstance();

$id = $segments[1] ?? null;

try {

    if ($method !== 'GET') {
        throw new Exception('Invalid request method.');
    }

    if (!$id) {

        $editions = $db->fetchAll(
            "SELECT
                id,
                title,
                publish_date,
                pdf_path
             FROM editions
             ORDER BY publish_date DESC"
        );

        echo json_encode([
            'status' => 'success',
            'data' => $editions,
            'meta' => [
                'total' => count($editions)
            ]
        ]);

        exit;
    }

    $edition = $db->fetch(
        "SELECT *
         FROM editions
         WHERE id = ?
         LIMIT 1",
        [$id]
    );

    if (!$edition) {
        throw new Exception('Edition not found.');
    }

    echo json_encode([
        'status' => 'success',
        'data' => $edition
    ]);

} catch (Throwable $e) {

    http_response_code(404);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}