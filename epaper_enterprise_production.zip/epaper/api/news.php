<?php
// api/news.php

require_once __DIR__ . '/../includes/Database.php';

header('Content-Type: application/json');

$db = Database::getInstance()->pdo();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

$stmt = $db->prepare("
    SELECT * FROM news
    WHERE page_number=? AND status='Published'
    ORDER BY position_order ASC
");

$stmt->execute([$page]);

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));