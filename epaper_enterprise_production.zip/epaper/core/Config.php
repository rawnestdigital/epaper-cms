<?php

class Config {

    private static array $data = [];

    public static function load(array $config) {

        self::$data = array_merge(self::$data, $config);
    }

    public static function get(string $key, $default = null) {

        return self::$data[$key] ?? $default;
    }

    public static function set(string $key, $value) {

        self::$data[$key] = $value;
    }
}