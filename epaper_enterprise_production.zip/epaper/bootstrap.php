<?php
require_once __DIR__ . '/config.php';
if(file_exists(BASE_PATH.'/vendor/autoload.php')) require_once BASE_PATH.'/vendor/autoload.php';
session_start();
ini_set('display_errors','0');
error_reporting(E_ALL);
spl_autoload_register(function($class){
 foreach(['includes'] as $dir){
   $f = BASE_PATH . "/$dir/$class.php";
   if(file_exists($f)) require_once $f;
 }
});
set_exception_handler(function($e){
 file_put_contents(LOG_PATH.'/error.log',$e->getMessage().PHP_EOL,FILE_APPEND);
 http_response_code(500);
 echo 'Server Error';
});
$db = Database::getInstance();
$security = new Security();
SecurityHeaders::apply();
<?php

ini_set('display_errors', '0');

error_reporting(E_ALL);

set_exception_handler(function ($e) {

    file_put_contents(
        LOG_PATH . '/error.log',
        '[' . date('Y-m-d H:i:s') . '] ' .
        $e->getMessage() .
        PHP_EOL,
        FILE_APPEND
    );

    http_response_code(500);

    echo 'Server Error';
});

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=()');

header(
    "Content-Security-Policy:
    default-src 'self';
    img-src 'self' data: https:;
    style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;
    script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;
    font-src 'self' data:;
    connect-src 'self';"
);
<?php
declare(strict_types=1);

/*
|---------------------------------------------------------
| MASTER BOOTSTRAP (ENTERPRISE INIT)
|---------------------------------------------------------
| Order is critical:
| 1. Database
| 2. Settings
| 3. Workflow
| 4. LayoutAI (optional runtime)
|---------------------------------------------------------
*/

/* -------------------------
   CORE CLASS LOADING
-------------------------- */
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/Settings.php';
require_once __DIR__ . '/includes/Workflow.php';
require_once __DIR__ . '/includes/LayoutAI.php';

/* -------------------------
   DB INIT (SINGLE SOURCE)
-------------------------- */
$db = Database::getInstance()->pdo();

/* -------------------------
   SETTINGS INIT
-------------------------- */
$settings = new Settings();

/* -------------------------
   WORKFLOW INIT
-------------------------- */
$workflow = new Workflow();

/* -------------------------
   OPTIONAL AI ENGINE INIT
   (Only instantiated when needed)
-------------------------- */
$ai = new LayoutAI();

/* -------------------------
   GLOBAL HELPERS
-------------------------- */
function setting($key) {
    global $settings;
    return $settings->get($key);
}

/* -------------------------
   ERROR SAFETY (PRODUCTION)
-------------------------- */
error_reporting(E_ALL);
ini_set('display_errors', 0);

/* END BOOTSTRAP */
<?php


require_once __DIR__ . '/config.php';


session_name('EPAPERSESSID');


if (session_status() === PHP_SESSION_NONE) {

session_start();

}


if (!isset($_SESSION['initiated'])) {

session_regenerate_id(true);

$_SESSION['initiated'] = true;

}


spl_autoload_register(function ($class) {


$path = BASE_PATH . '/includes/' . $class . '.php';


if (file_exists($path)) {

require_once $path;

}

});


header('X-Frame-Options: SAMEORIGIN');

header('X-Content-Type-Options: nosniff');

header('Referrer-Policy: strict-origin');

header('Permissions-Policy: geolocation=()');


$db = Database::getInstance();

$security = new Security();

