<?php


require_once '../../bootstrap.php';


header('Content-Type: application/json');


try {


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

throw new Exception('Invalid request method.');

}


$csrf = $_POST['csrf_token'] ?? '';


if (!$security->validateCsrf($csrf)) {

throw new Exception('CSRF validation failed.');

}


$userId = (int) ($_POST['user_id'] ?? 0);


$plan = trim($_POST['plan'] ?? '');


$amount = (float) ($_POST['amount'] ?? 0);


if ($userId <= 0 || empty($plan) || $amount <= 0) {

throw new Exception('Invalid payment payload.');

}


$txnId = 'TXN-' . strtoupper(bin2hex(random_bytes(5)));


$db = Database::getInstance();


$db->query(

"INSERT INTO payments

(user_id, txn_id, amount, gateway, status)

VALUES (?, ?, ?, ?, ?)",

[

$userId,

$txnId,

$amount,

'sandbox',

'success'

]

);


$subscription = new Subscription();


$expiry = date(

'Y-m-d H:i:s',

strtotime('+30 days')

);


$subscription->createSubscription(

$userId,

$plan,

$expiry

);


AuditLogger::log(

'payment_success',

'Transaction: ' . $txnId

);


echo json_encode([

'status' => 'success',

'message' => 'Payment successful.',

'transaction_id' => $txnId

]);


} catch (Throwable $e) {


http_response_code(400);


AuditLogger::log(

'payment_failed',

$e->getMessage()

);


echo json_encode([

'status' => 'error',

'message' => $e->getMessage()

]);

}

