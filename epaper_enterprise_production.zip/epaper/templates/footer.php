<footer class="epaper-footer">
    <div>
        © <?= date('Y') ?> All Rights Reserved
    </div>
</footer>

<script src="/assets/js/viewer.js"></script>

</body>
</html>
<?php

$settings = new Settings();

?>

<footer class="paper-footer">

    <div class="footer-grid">

        <div class="footer-col">

            <img
                class="footer-logo"
                src="/storage/uploads/<?= e($settings->get('site_logo')) ?>"
                alt=""
            >

            <p>
                <?= e($settings->get('site_tagline')) ?>
            </p>

        </div>

        <div class="footer-col">

            <h3>
                যোগাযোগ
            </h3>

            <p>
                সম্পাদক:
                <?= e($settings->get('editor_name')) ?>
            </p>

            <p>
                প্রকাশক:
                <?= e($settings->get('publisher_name')) ?>
            </p>

            <p>
                <?= e($settings->get('office_address')) ?>
            </p>

            <p>
                <?= e($settings->get('mobile')) ?>
            </p>

            <p>
                <?= e($settings->get('email')) ?>
            </p>

        </div>

        <div class="footer-col">

            <h3>
                গুরুত্বপূর্ণ লিংক
            </h3>

            <ul>

                <li>
                    <a href="/">
                        হোম
                    </a>
                </li>

                <li>
                    <a href="/epaper">
                        ই-পেপার
                    </a>
                </li>

                <li>
                    <a href="/contact">
                        যোগাযোগ
                    </a>
                </li>

            </ul>

        </div>

    </div>

    <div class="footer-bottom">

        <p>
            © <?= date('Y') ?>
            <?= e($settings->get('site_name')) ?>
        </p>

        <p>
            Developed by RawNest Digital
        </p>

    </div>

</footer>

</body>

</html>