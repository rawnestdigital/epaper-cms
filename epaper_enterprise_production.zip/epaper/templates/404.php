<?php
require BASE_PATH . '/templates/header.php';
?>

<section class="error-page">

    <div class="error-box">

        <h1>
            404
        </h1>

        <p>
            সংবাদ পাওয়া যায়নি
        </p>

        <a href="/">
            হোমপেজে ফিরুন
        </a>

    </div>

</section>

<?php
require BASE_PATH . '/templates/footer.php';