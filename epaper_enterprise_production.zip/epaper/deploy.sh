#!/bin/bash

# ====================================
# Enterprise ePaper CMS Deployment
# ====================================

set -e

echo "====================================="
echo "Enterprise ePaper CMS Deployment"
echo "====================================="

# Move to docker directory
cd docker

echo ""
echo "Stopping existing containers..."
docker-compose down

echo ""
echo "Building containers..."
docker-compose build --no-cache

echo ""
echo "Starting containers..."
docker-compose up -d

echo ""
echo "Waiting for services..."
sleep 10

echo ""
echo "Setting permissions..."

docker exec enterprise_epaper_app \
    chmod -R 755 /var/www/html/storage

docker exec enterprise_epaper_app \
    chmod -R 755 /var/www/html/database

docker exec enterprise_epaper_app \
    chown -R www-data:www-data /var/www/html/storage

docker exec enterprise_epaper_app \
    chown -R www-data:www-data /var/www/html/database

echo ""
echo "Creating SQLite database if missing..."

docker exec enterprise_epaper_app \
    sh -c 'touch /var/www/html/database/epaper.sqlite'

echo ""
echo "Running schema migrations..."

docker exec -i enterprise_epaper_app \
    sh -c 'sqlite3 /var/www/html/database/epaper.sqlite < /var/www/html/schema.sql'

echo ""
echo "Optimizing Composer autoload..."

docker exec enterprise_epaper_app \
    composer dump-autoload -o || true

echo ""
echo "Deployment completed successfully."

echo ""
echo "Application URL:"
echo "http://localhost:8080"

echo ""
echo "Useful commands:"
echo "docker ps"
echo "docker logs enterprise_epaper_app"
echo "docker exec -it enterprise_epaper_app sh"
