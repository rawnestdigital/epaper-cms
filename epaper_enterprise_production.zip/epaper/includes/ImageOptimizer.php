<?php


class ImageOptimizer {


public function optimize($source, $destination, $quality = 80) {


$info = getimagesize($source);


if ($info['mime'] === 'image/jpeg') {

$image = imagecreatefromjpeg($source);

imagejpeg($image, $destination, $quality);

}

}

}

