const modal = document.getElementById('newsModal');

const closeModal = document.getElementById('closeModal');

const modalImage = document.getElementById('modalImage');

const modalTitle = document.getElementById('modalTitle');

const modalContent = document.getElementById('modalContent');

const fullPageFrame = document.getElementById('fullPageFrame');

const imageView = document.querySelector('.modal-image-view');

const textView = document.querySelector('.modal-text-view');

const fullView = document.querySelector('.modal-full-view');

document.querySelectorAll('.news-block').forEach(block => {

    block.addEventListener('click', () => {

        const title = block.dataset.title;

        const image = block.dataset.image;

        const content = block.dataset.content;

        modal.classList.add('active');

        modalImage.src = image;

        modalTitle.innerHTML = title;

        modalContent.innerHTML = content;

        imageView.classList.add('active');

        textView.classList.remove('active');

        fullView.classList.remove('active');

        fullPageFrame.src = window.location.href;
    });
});

closeModal.addEventListener('click', () => {

    modal.classList.remove('active');
});

document.querySelectorAll('[data-view]').forEach(button => {

    button.addEventListener('click', () => {

        const type = button.dataset.view;

        imageView.classList.remove('active');

        textView.classList.remove('active');

        fullView.classList.remove('active');

        if(type === 'image'){
            imageView.classList.add('active');
        }

        if(type === 'text'){
            textView.classList.add('active');
        }

        if(type === 'full'){
            fullView.classList.add('active');
        }
    });
});

document.getElementById('copyLink')
.addEventListener('click', () => {

    navigator.clipboard.writeText(window.location.href);
});

document.getElementById('downloadBtn')
.addEventListener('click', () => {

    window.print();
});

window.addEventListener('click', e => {

    if(e.target === modal){
        modal.classList.remove('active');
    }
});

function shareLinks(){

    const url = encodeURIComponent(window.location.href);

    document.getElementById('shareWhatsapp')
    .href = `https://wa.me/?text=${url}`;

    document.getElementById('shareFacebook')
    .href = `https://facebook.com/sharer/sharer.php?u=${url}`;

    document.getElementById('shareX')
    .href = `https://twitter.com/intent/tweet?url=${url}`;

    document.getElementById('shareEmail')
    .href = `mailto:?subject=ePaper&body=${url}`;
}

shareLinks();