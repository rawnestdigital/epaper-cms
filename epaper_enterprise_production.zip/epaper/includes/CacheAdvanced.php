<?php


class CacheAdvanced extends Cache {


public function remember($key, callable $callback, $ttl = 3600) {


$cached = $this->get($key);


if ($cached !== false) {

return $cached;

}


$data = $callback();


$this->set($key, $data, $ttl);


return $data;

}

}

