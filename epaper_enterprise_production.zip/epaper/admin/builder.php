<?php
// admin/builder.php (FINAL PATCH INTEGRATION BLOCK ONLY)
?>

<script>
function saveSpan(id, span){
    fetch('/api/builder-sync.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            type:'span',
            id:id,
            span:span
        })
    });
}

function saveOrder(items){
    fetch('/api/builder-sync.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            type:'order',
            items:items
        })
    });
}

new Sortable(document.getElementById('grid'),{
    animation:150,
    onEnd:function(){
        const items=[...document.querySelectorAll('.news-item')].map((el,i)=>({
            id:el.dataset.id,
            position:i
        }));
        saveOrder(items);
    }
});
</script>
// admin/builder.php

require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Security.php';

Security::startSession();
Security::requireRole(['Admin','Editor']);

$db = Database::getInstance()->pdo();

$page = $_GET['page'] ?? 1;

$news = $db->prepare("SELECT * FROM news WHERE page_number=? ORDER BY position_order ASC");
$news->execute([$page]);
$news = $news->fetchAll(PDO::FETCH_ASSOC);
?>

<div id="grid">

<?php foreach($news as $n): ?>
<div class="news-item col-<?= $n['column_span'] ?>" data-id="<?= $n['id'] ?>">
<?= $n['title'] ?>

<select onchange="updateSpan(<?= $n['id'] ?>, this.value)">
<?php for($i=1;$i<=12;$i++): ?>
<option value="<?= $i ?>"><?= $i ?></option>
<?php endfor; ?>
</select>

</div>
<?php endforeach; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
new Sortable(document.getElementById('grid'), {
    animation: 150,
    onEnd: function () {
        fetch('/api/update-layout.php', {
            method: 'POST',
            body: JSON.stringify([...document.querySelectorAll('.news-item')].map((e,i)=>({
                id:e.dataset.id,
                position:i
            })))
        });
    }
});

function updateSpan(id, span){
    fetch('/api/update-layout.php',{
        method:'POST',
        body:JSON.stringify({type:'span',id,span})
    });
}
</script>
<button onclick="runAI()">🧠 Auto Layout (AI Editor)</button>

<script>
function runAI() {
    fetch('/api/auto-layout.php?page=<?= $page ?>')
    .then(res => res.json())
    .then(data => {
        alert("AI Layout Applied: " + data.items + " items rearranged");
        location.reload();
    });
}
</script>
<?php
require_once '../includes/Database.php';

$db = Database::getInstance()->pdo();

$page = $_GET['page'] ?? 1;

$stmt = $db->prepare("SELECT * FROM news WHERE page_number = ? ORDER BY position_order ASC");
$stmt->execute([$page]);
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="/assets/css/epaper.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.css">

<h2> 12-Column Layout Builder (Page <?= $page ?>)</h2>

<button onclick="generatePDF()"> Generate PDF</button>

<div id="builderGrid" class="epaper-container">

<?php foreach ($news as $n): ?>
    <div class="news-item col-<?= $n['column_span'] ?>"
         data-id="<?= $n['id'] ?>"
         data-span="<?= $n['column_span'] ?>">

        <strong><?= htmlspecialchars($n['title']) ?></strong>

        <div>
            <label>Span:</label>
            <select onchange="updateSpan(<?= $n['id'] ?>, this.value)">
                <?php for ($i=1; $i<=12; $i++): ?>
                    <option value="<?= $i ?>" <?= $i==$n['column_span']?'selected':'' ?>>
                        <?= $i ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>

    </div>
<?php endforeach; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script src="/assets/js/builder.js"></script>