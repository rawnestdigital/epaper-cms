<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;700&display=swap" rel="stylesheet">
<style>body{font-family:'Hind Siliguri',sans-serif;}</style>
</head>
<body>
<div id="breakingBar" class="breaking-bar">
    লোড হচ্ছে ব্রেকিং নিউজ...
</div>
<?php
require_once __DIR__ . '/../includes/Settings.php';

$settings = new Settings();

/* Branding Data */
$site_name = $settings->get('site_name');
$tagline = $settings->get('tagline');
$logo = $settings->get('logo');
$editor = $settings->get('editor_name');
$address = $settings->get('address');
$reg_no = $settings->get('reg_no');

/* Bengali Date Helper */
function bengali_date() {
    $bn_days = ['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
    $bn_months = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];

    $day = $bn_days[date('w')];
    $date = date('j');
    $month = $bn_months[date('n') - 1];
    $year = date('Y');

    return "$day, $date $month $year";
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($site_name) ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="/assets/css/epaper.css">
</head>

<body>

<header class="epaper-header">

    <div class="top-bar">
        <div class="date"><?= bengali_date(); ?></div>
        <div class="reg">Reg: <?= htmlspecialchars($reg_no) ?></div>
    </div>

    <div class="brand">
        <?php if ($logo): ?>
            <img src="/uploads/<?= $logo ?>" class="logo">
        <?php endif; ?>

        <div class="title">
            <h1><?= htmlspecialchars($site_name) ?></h1>
            <p><?= htmlspecialchars($tagline) ?></p>
        </div>
    </div>

    <div class="meta">
        <span>সম্পাদক: <?= htmlspecialchars($editor) ?></span>
        <span><?= htmlspecialchars($address) ?></span>
    </div>

</header>
<?php

$settings = new Settings();

$dateEnglish = date('d F Y');

$dateBangla = bn_date(date('Y-m-d'));

$logo = $settings->get('site_logo');

?>

<!DOCTYPE html>

<html lang="bn">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
<?= e($settings->get('site_name')) ?>
</title>

<link
rel="stylesheet"
href="<?= asset('css/epaper-ui.css') ?>"
>

<link
href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap"
rel="stylesheet"
>

</head>

<body>

<header class="paper-header">

    <div class="header-left">

        <span>
            <?= $dateEnglish ?>
        </span>

        <span>
            <?= $dateBangla ?>
        </span>

        <span class="edition-label">
            অনলাইন সংস্করণ
        </span>

    </div>

    <div class="header-center">

        <a href="/">

            <img
                src="/storage/uploads/<?= e($logo) ?>"
                alt="Logo"
            >

        </a>

    </div>

    <div class="header-right">

        <a href="<?= e($settings->get('facebook')) ?>">
            Facebook
        </a>

        <a href="<?= e($settings->get('youtube')) ?>">
            YouTube
        </a>

        <a href="<?= e($settings->get('twitter')) ?>">
            X
        </a>

        <button class="online-btn">
            Online
        </button>

    </div>

</header>
<?php

$db = Database::getInstance();

$paperName = $db->fetch(
    "SELECT setting_value
     FROM settings
     WHERE setting_key='paper_name'"
);

$paperPhone = $db->fetch(
    "SELECT setting_value
     FROM settings
     WHERE setting_key='paper_phone'"
);
?>

<header class="paper-header">

    <h1><?= e($paperName['setting_value']) ?></h1>

    <p>
        ফোন:
        <?= e($paperPhone['setting_value']) ?>
    </p>

</header>