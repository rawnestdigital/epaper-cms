<?php
// admin/login.php

require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Security.php';

Security::startSession();

$db = Database::getInstance()->pdo();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!Security::verifyCsrf($_POST['csrf'] ?? null)) {
        exit;
    }

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $db->prepare("
        SELECT users.*, roles.name AS role
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE email = ?
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {

        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['name'],
            'role' => $user['role']
        ];

        header('Location: /admin/news.php');
        exit;
    }

    $error = 'Invalid login';
}

$token = Security::csrfToken();
?>

<form method="POST">
    <input type="hidden" name="csrf" value="<?= $token ?>">
    <input type="email" name="email" required>
    <input type="password" name="password" required>
    <button>Login</button>
</form>

<div><?= $error ?></div>
<?php

require_once '../config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {


if ($security->login($_POST['username'], $_POST['password'])) {


AuditLogger::log('login');


header('Location: index.php');

exit;

}

}

?>


<form method="post">


<input type="text" name="username" placeholder="Username">

<input type="password" name="password" placeholder="Password">


<button type="submit">Login</button>


</form>

