<?php
// admin/settings.php

require_once __DIR__ . '/../includes/Security.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Settings.php';

Security::startSession();
Security::requireRole(['Admin']);

$db = Database::getInstance()->pdo();
$settings = new Settings($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!Security::verifyCsrf($_POST['csrf'] ?? null)) {
        exit;
    }

    foreach ($_POST as $k => $v) {
        if ($k === 'csrf') continue;
        $settings->set($k, trim((string)$v));
    }

    if (!empty($_FILES['logo']['name'])) {
        $dir = __DIR__ . '/../uploads/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);

        $file = time() . '_' . basename($_FILES['logo']['name']);
        move_uploaded_file($_FILES['logo']['tmp_name'], $dir . $file);

        $settings->set('logo', $file);
    }
}

$data = $settings->all();
$csrf = Security::csrfToken();
?>

<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= $csrf ?>">

<input name="site_name" value="<?= $data['site_name'] ?? '' ?>">
<input name="tagline" value="<?= $data['tagline'] ?? '' ?>">
<input name="editor_name" value="<?= $data['editor_name'] ?? '' ?>">
<textarea name="address"><?= $data['address'] ?? '' ?></textarea>
<input name="reg_no" value="<?= $data['reg_no'] ?? '' ?>">

<input type="file" name="logo">

<button>Save</button>
</form>
<?php
require_once '../includes/Settings.php';

$settings = new Settings();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    foreach ($_POST as $key => $value) {
        if ($key !== 'logo') {
            $settings->set($key, htmlspecialchars($value));
        }
    }

    // Logo upload (NO GD)
    if (!empty($_FILES['logo']['name'])) {
        $uploadDir = "../uploads/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["logo"]["name"]);
        $target = $uploadDir . $fileName;

        move_uploaded_file($_FILES["logo"]["tmp_name"], $target);

        $settings->set('logo', $fileName);
    }

    echo "Settings Updated Successfully";
}

$data = $settings->all();
?>

<h2>Site Settings</h2>

<form method="POST" enctype="multipart/form-data">

    <label>Site Name</label>
    <input type="text" name="site_name" value="<?= $data['site_name'] ?? '' ?>">

    <label>Tagline</label>
    <input type="text" name="tagline" value="<?= $data['tagline'] ?? '' ?>">

    <label>Editor Name</label>
    <input type="text" name="editor_name" value="<?= $data['editor_name'] ?? '' ?>">

    <label>Office Address</label>
    <textarea name="address"><?= $data['address'] ?? '' ?></textarea>

    <label>Social Links</label>
    <input type="text" name="social_links" value="<?= $data['social_links'] ?? '' ?>">

    <label>Registration No</label>
    <input type="text" name="reg_no" value="<?= $data['reg_no'] ?? '' ?>">

    <label>Logo</label>
    <input type="file" name="logo">

    <button type="submit">Save Settings</button>
</form>
<?php
require_once '../bootstrap.php';

$security->auth();

$settings = new Settings();

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    foreach($_POST as $key => $value){

        $settings->set(
            trim($key),
            trim($value)
        );
    }

    if(!empty($_FILES['site_logo']['name'])){

        $upload = new ImagePipeline();

        $logo = $upload->upload($_FILES['site_logo']);

        $settings->set('site_logo', $logo);
    }

    header('Location: settings.php?saved=1');

    exit;
}
?>

<link
rel="stylesheet"
href="<?= asset('css/epaper-ui.css') ?>"
>

<div class="admin-wrapper">

    <div class="admin-card">

        <h1>
            পত্রিকা সেটিংস
        </h1>

        <form
            method="POST"
            enctype="multipart/form-data"
        >

            <div class="settings-grid">

                <div class="form-group">

                    <label>
                        সাইট নাম
                    </label>

                    <input
                        type="text"
                        name="site_name"
                        value="<?= e($settings->get('site_name')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        ট্যাগলাইন
                    </label>

                    <input
                        type="text"
                        name="site_tagline"
                        value="<?= e($settings->get('site_tagline')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        লোগো আপলোড
                    </label>

                    <input
                        type="file"
                        name="site_logo"
                    >

                </div>

                <div class="form-group">

                    <label>
                        সম্পাদক
                    </label>

                    <input
                        type="text"
                        name="editor_name"
                        value="<?= e($settings->get('editor_name')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        প্রকাশক
                    </label>

                    <input
                        type="text"
                        name="publisher_name"
                        value="<?= e($settings->get('publisher_name')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        অফিস ঠিকানা
                    </label>

                    <textarea
                        name="office_address"
                    ><?= e($settings->get('office_address')) ?></textarea>

                </div>

                <div class="form-group">

                    <label>
                        মোবাইল
                    </label>

                    <input
                        type="text"
                        name="mobile"
                        value="<?= e($settings->get('mobile')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        ইমেইল
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?= e($settings->get('email')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        রেজি নং
                    </label>

                    <input
                        type="text"
                        name="reg_no"
                        value="<?= e($settings->get('reg_no')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        ফেসবুক
                    </label>

                    <input
                        type="url"
                        name="facebook"
                        value="<?= e($settings->get('facebook')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        ইউটিউব
                    </label>

                    <input
                        type="url"
                        name="youtube"
                        value="<?= e($settings->get('youtube')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        এক্স
                    </label>

                    <input
                        type="url"
                        name="twitter"
                        value="<?= e($settings->get('twitter')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        হোয়াটসঅ্যাপ
                    </label>

                    <input
                        type="url"
                        name="whatsapp"
                        value="<?= e($settings->get('whatsapp')) ?>"
                    >

                </div>

                <div class="form-group">

                    <label>
                        হেডলাইন ফন্ট
                    </label>

                    <select name="headline_font">

                        <option value="Hind Siliguri">
                            Hind Siliguri
                        </option>

                        <option value="SolaimanLipi">
                            SolaimanLipi
                        </option>

                    </select>

                </div>

            </div>

            <button class="save-btn">
                সেটিংস সংরক্ষণ করুন
            </button>

        </form>

    </div>

</div>
<?php
require_once '../bootstrap.php';

$security->auth();

$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    foreach ($_POST as $key => $value) {

        $db->query(
            'UPDATE settings
             SET setting_value = ?
             WHERE setting_key = ?',
            [$value, $key]
        );
    }

    header('Location: settings.php');
    exit;
}

$settings = $db->fetchAll(
    'SELECT * FROM settings'
);
?>

<form method="POST">

    <h2>পত্রিকার তথ্য</h2>

    <div class="form-group">

        <label>পত্রিকার নাম</label>

        <input
            type="text"
            name="paper_name"
        >

    </div>

    <div class="form-group">

        <label>ফোন নম্বর</label>

        <input
            type="text"
            name="paper_phone"
        >

    </div>

    <div class="form-group">

        <label>ঠিকানা</label>

        <textarea name="paper_address"></textarea>

    </div>

    <div class="form-group">

        <label>রেজি নং</label>

        <input
            type="text"
            name="paper_reg_no"
        >

    </div>

    <button type="submit">
        সেটিংস সংরক্ষণ করুন
    </button>

</form>
