<?php

$db = Database::getInstance();

try {

    if ($method !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    $headers = getallheaders();

    $authHeader = $headers['Authorization'] ?? '';

    if (
        !preg_match(
            '/Bearer\\s+(.*)$/i',
            $authHeader,
            $matches
        )
    ) {
        throw new Exception('Missing bearer token.');
    }

    $token = trim($matches[1]);

    $payload = JWT::decode($token);

    $userId = (int) $payload['id'];

    $input = json_decode(
        file_get_contents('php://input'),
        true
    );

    $plan = trim($input['plan'] ?? '');

    if (
        !in_array(
            $plan,
            ['premium', 'epaper_only', 'vip'],
            true
        )
    ) {
        throw new Exception('Invalid subscription plan.');
    }

    $subscription = new Subscription();

    $expiresAt = date(
        'Y-m-d H:i:s',
        strtotime('+30 days')
    );

    $subscription->createSubscription(
        $userId,
        $plan,
        $expiresAt
    );

    AuditLogger::log(
        'subscription_updated',
        'User ID: ' . $userId
    );

    echo json_encode([
        'status' => 'success',
        'data' => [
            'plan' => $plan,
            'expires_at' => $expiresAt
        ]
    ]);

} catch (Throwable $e) {

    http_response_code(401);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}