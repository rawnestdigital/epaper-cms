<?php

require_once '../bootstrap.php';

$security->auth();

$upload = new ImagePipeline();

if(
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    !empty($_FILES['media']['name'])
){

    $upload->upload($_FILES['media']);

    header('Location: media.php');

    exit;
}

$files = glob(
    BASE_PATH . '/storage/uploads/*'
);

?>

<link
rel="stylesheet"
href="<?= asset('css/admin-dashboard.css') ?>"
>

<div class="admin-dashboard">

    <aside class="admin-sidebar">

        <div class="admin-logo">
            CMS
        </div>

        <nav>

            <a href="index.php">
                ড্যাশবোর্ড
            </a>

            <a href="news.php">
                সংবাদ
            </a>

            <a href="editions.php">
                সংস্করণ
            </a>

            <a href="media.php">
                মিডিয়া
            </a>

            <a href="settings.php">
                সেটিংস
            </a>

            <a href="logout.php">
                লগআউট
            </a>

        </nav>

    </aside>

    <main class="admin-main">

        <div class="page-header">

            <h1>
                মিডিয়া ম্যানেজার
            </h1>

        </div>

        <div class="admin-form-card">

            <form
                method="POST"
                enctype="multipart/form-data"
            >

                <div class="form-group">

                    <label>
                        ফাইল আপলোড
                    </label>

                    <input
                        type="file"
                        name="media"
                        required
                    >

                </div>

                <button class="save-btn">

                    আপলোড করুন

                </button>

            </form>

        </div>

        <div class="media-grid">

            <?php foreach($files as $file): ?>

                <div class="media-card">

                    <img
                        src="/storage/uploads/<?= basename($file) ?>"
                        alt=""
                    >

                    <div class="media-name">

                        <?= e(basename($file)) ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </main>

</div>