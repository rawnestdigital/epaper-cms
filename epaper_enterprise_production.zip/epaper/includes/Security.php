<?php
class Security {
    public function csrfToken() {
        if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf'];
    }
    public function validateCsrf($token) {
        return hash_equals($_SESSION['csrf'], $token);
    }
    public function sanitize($data) {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    public function login($username, $password) {
        $db = Database::getInstance();
        $user = $db->fetch("SELECT * FROM users WHERE username=? LIMIT 1", [$username]);
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $user['id'], 'role' => $user['role'], 'username' => $user['username']];
            return true;
        }
        return false;
    }
    public function requireLogin() {
        if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }
    }
    public function hasRole($role) {
        return isset($_SESSION['user']) && $_SESSION['user']['role'] === $role;
    }
}
<?php
// includes/Security.php

declare(strict_types=1);

final class Security
{
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path' => '/',
                'domain' => '',
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Strict'
            ]);

            session_start();
            session_regenerate_id(true);
        }
    }

    public static function csrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function verifyCsrf(?string $token): bool
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
    }

    public static function requireLogin(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: /admin/login.php');
            exit;
        }
    }

    public static function userRole(): ?string
    {
        return $_SESSION['user']['role'] ?? null;
    }

    public static function requireRole(array $roles): void
    {
        self::requireLogin();
        if (!in_array(self::userRole(), $roles, true)) {
            http_response_code(403);
            exit;
        }
    }
}
<?php


class Security {


public function csrf(): string {


if (empty($_SESSION['csrf_token'])) {

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

}


return $_SESSION['csrf_token'];

}


public function validateCsrf(string $token): bool {


return isset($_SESSION['csrf_token']) &&

hash_equals($_SESSION['csrf_token'], $token);

}


public function clean(string $value): string {


return trim(strip_tags($value));

}


public function escape(string $value): string {


return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');

}


public function login(string $username, string $password): bool {


$db = Database::getInstance();


$user = $db->fetch(

'SELECT * FROM users WHERE username = ? LIMIT 1',

[$username]

);


if (!$user) {

return false;

}


if (!password_verify($password, $user['password'])) {

return false;

}


session_regenerate_id(true);


$_SESSION['user'] = [

'id' => $user['id'],

'name' => $user['name'],

'role' => $user['role']

];


return true;

}


public function auth(): void {


if (!isset($_SESSION['user'])) {

header('Location: /admin/login.php');

exit;

}
<?php


class Security {


public function csrfToken() {


if (empty($_SESSION['csrf'])) {

$_SESSION['csrf'] = bin2hex(random_bytes(32));

}


return $_SESSION['csrf'];

}


public function validateCsrf($token) {

return hash_equals($_SESSION['csrf'], $token);

}


public function sanitize($data) {

return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');

}


public function login($username, $password) {


$db = Database::getInstance();


$user = $db->fetch(

"SELECT * FROM users WHERE username=? LIMIT 1",

[$username]

);


if ($user && password_verify($password, $user['password'])) {


session_regenerate_id(true);


$_SESSION['user'] = [

'id' => $user['id'],

'role' => $user['role'],

'username' => $user['username']

];


return true;

}


return false;

}


public function requireLogin() {


if (!isset($_SESSION['user'])) {

header('Location: login.php');

exit;

}

}


public function hasRole($role) {

return isset($_SESSION['user']) && $_SESSION['user']['role'] === $role;

}

}



