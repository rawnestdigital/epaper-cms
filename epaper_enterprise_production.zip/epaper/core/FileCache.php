<?php

class FileCache implements Cache {

    private string $path;

    public function __construct() {

        $this->path = BASE_PATH . '/storage/cache/';
    }

    private function file(string $key): string {

        return $this->path . md5($key) . '.cache';
    }

    public function get(string $key) {

        $file = $this->file($key);

        if(!file_exists($file)) return null;

        $data = unserialize(file_get_contents($file));

        if($data['expire'] < time()) {

            unlink($file);

            return null;
        }

        return $data['value'];
    }

    public function set(string $key, $value, int $ttl = 3600) {

        if(!is_dir($this->path)) {

            mkdir($this->path, 0775, true);
        }

        $data = [

            'value' => $value,

            'expire' => time() + $ttl
        ];

        file_put_contents($this->file($key), serialize($data));
    }

    public function delete(string $key) {

        $file = $this->file($key);

        if(file_exists($file)) unlink($file);
    }

    public function clear() {

        foreach(glob($this->path . '*.cache') as $file) {

            unlink($file);
        }
    }
}